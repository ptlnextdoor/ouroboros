# SQ-2 Bill of Materials (purchased parts)

Status as of 2026-10-15. Every row: what, why this part, vendor source, CAD source, mass source.
"Model" column: how `sq2/vehicle.py` represents it. Unverified claims are marked.

| # | Part | Qty | Mass (g, each) | Source / datasheet | CAD | Model | Status |
|---|---|---|---|---|---|---|---|
| 1 | T-Motor VELOX V3120, 900 KV wind | 4 | 148.1 (vendor, 700KV incl. leads) | tmotorhobby.com V3120 page; drawing `data/vendor_docs/tmotor-v3120-motor-drawing.jpg`; test tables `tmotor_v3120_test_tables.csv` (500/700 KV) | Built from vendor drawing (no vendor STEP found: T-Motor download centre is JS-only, GrabCAD model needs login) | 700 KV calibrated to vendor table; 900 KV = `rewound_motor()` scaling (R ~ 1/Kv^2) | **OPEN**: 900 KV not in T-Motor's current catalogue (UK dealer: only 500/700). Peregreen V4 reportedly ran 900 KV. Options: (a) ask T-Motor for 900 KV, (b) rewind 700 KV, (c) AOS Supernova 3220 925 KV (catalogue part; needs test data). Bench-test before relying on the scaling. |
| 2 | APD 200F3[X]v2 ESC, 14S 200 A | 4 | 36 (vendor) | powerdrives.net/200f3; datasheet `data/vendor_docs/APD_200F3Xv2_datasheet_Rev2.0.pdf` | **Vendor STEP** `cad/vendor/APD_200F3.step` (73.0 x 33.6 x 13.0 mm) | mass, envelope, 2 % loss, adiabatic thermal | Real part, in stock at GetFPV / NeuMotors. Blackbird flew this ESC uncooled. |
| 2b | APD 120F3[X]v2 ESC, 12S 120 A | 4 | 20 (vendor) | powerdrives.net/120f3 | **Vendor STEP** `cad/vendor/APD_120F3.step` (59.0 x 29.0 x 14.1 mm) | 12S option | Real part. |
| 3 | Propeller APC 7x15E (LP07015E), clipped to 5.75 in | 4 (+8 spares) | 9.9 full, ~6.7 clipped | apcprop.com; geometry `data/apc_geom/7x15E-PERF.PE0`, performance PER3 | Lofted from APC PE0 geometry (real chord/twist/thickness) | Calibrated BEM, APC difference correction, extended to 42k rpm | Real part. **Requires spin test** of every clipped prop + spinner to 43.2k rpm (1.2 x 36k) behind a shield: APC's published limit for E props is 150000/D = 21.4k rpm at 7 in. Both record vehicles ran this prop at 30-40k. |
| 4 | Battery: custom 7S LiPo, R-Line V5 cells, capacity per optimizer | 2 | scaled 26.4 g per cell-Ah from the catalogue 6S1400 (222 g) | Tattu custom-pack service (tattuworld.com "Customized"); catalogue reference: Tattu R-Line V5 6S 1400 150C | Envelope box (catalogue 78 x 39 x 42 mm scaled: thickness by cells, length by capacity) | IR 2.5 mOhm/cell at 1400 mAh, scaled 1/capacity (**ASSUMPTION**) | **OPEN**: request quote; measure IR at delivery. Fallback: 12S2P 4x catalogue 6S1400 (option 0 in `POWER`). |
| 5 | CFRP tube (spar) | 2 | from geometry | roll-wrapped/pultruded commodity tube, OD/ID per optimizer (`SPARS`) | modelled | E 100 GPa, G 4 GPa, sigma 600 MPa (**conservative typical**) | Order from Rock West / Dragonplate / Easy Composites; verify tensile datasheet. |
| 6 | Spar cross frame, 7075-T6 plate | 1 | 22 (est.) | SendCutSend (waterjet/laser 7075) + drill | `cad/out/sq2/spar_cross_frame.step` | point mass | Design in CAD; FEA todo. |
| 7 | Pod node, AlSi10Mg LPBF (topology-optimised) | 4 | 14 (incl. margin; part 10 g) | JLC3DP / Xometry metal | `sq2/out/pod_node.stl` | point mass | CalculiX cross-check 5-14 MPa vs 200 MPa allowable. Needs regeneration for SQ-2 spar size and pod OD. |
| 8 | Avionics: FC, ADR board (in-house), GNSS, RX, VTX + camera, antenna, current sensor, bus capacitor | 1 set | 82 total | ADR: `electronics/sq1_adr/` (60 x 38 mm, 9.5 g) | ADR board STEP from KiCad (todo) | point mass | ADR PCB in fab prep (worker). Rest of avionics: selection todo. |
| 9 | Power wiring 12 AWG silicone, XT90/AS150 connectors, phase leads 16 AWG | set | 230 total | | wire routes todo | point mass | Harness design todo (C3). |
| 10 | Fasteners, heat-set inserts, adhesive | set | 60 | | | point mass | |

Printed parts (PAHT-CF on Bambu H2D, 325 x 320 x 325 mm): fuselage sections (split at the
spar cross frame and at <= 300 mm), 4 nacelles, 4 strut fairings, 4 spinners; TPU 95A fins.
Files: `cad/out/sq2/*.step|stl`. Surface finish requirement R11: ks <= 10 um (filled, sanded
to 600 grit, clear coat), because the sensitivity study shows ks 30 um costs ~34 km/h.

Mass growth allowance: +8 % of everything above (AIAA S-120A conceptual stage), carried in
the model and in the CG.
