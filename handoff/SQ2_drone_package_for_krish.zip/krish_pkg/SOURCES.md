# SQ-2 Sources

Every external number used in the model or the CAD, where it came from, and how it is used.
Local copies live in `data/vendor_docs/` and `cad/vendor/`.

## Purchased parts (vendor data)
| Item | Value(s) used | Source | Used in |
|---|---|---|---|
| T-Motor V3120 500/700 KV | R 76.35/40.59 mOhm, 146.7/148.1 g, peak 68.9/79.4 A (10 s), 3242/2453 W, bell D37.2, L 56.1, 3-12S | `data/vendor_docs/tmotor-v3120-motor-specifications.jpg`, `-drawing.jpg`, `tmotor_v3120_test_tables.csv` (tmotorhobby.com V3120 page) | `analysis/propulsion.py calibrated_motor()`, CAD motor envelope |
| AOS Supernova 3220 925 KV | 25 mOhm, 130 g, idle 2.1 A, 80.8 A / 1939 W (15 s), 5-6S | RCinPower listing (made-in-china.com product page, Oct 2026); aos-rc.com design page | `analysis/propulsion.py aos_3220_925()` |
| APD 120F3[X]v2 | 12S, 120 A cont, 20 g, 59 x 29 x 14.1 mm | powerdrives.net/120f3; STEP from docs.powerdrives.net 3D downloads | `cad/vendor/APD_120F3.step`, `vehicle.ESCS[12]` |
| APD 200F3[X]v2 | 14S, 200 A cont / 300 A burst, 36 g, 73 x 33.6 x 13.0 mm (STEP bbox) | powerdrives.net/200f3; datasheet `data/vendor_docs/APD_200F3Xv2_datasheet_Rev2.0.pdf` | `cad/vendor/APD_200F3.step`, `vehicle.ESCS[14]` |
| APD HV_Pro16S | 16S, 260 g, 96 x 53 x 27 mm, 300 A burst | `data/vendor_docs/APD_HV_Pro16S_datasheet_Rev2.0.pdf` | `cad/vendor/APD_HV_Pro.step`, `vehicle.ESCS[16]` |
| Tattu R-Line V5 6S 1400 150C | 222 g, 78 x 39 x 42 mm | getfpv.com / tattuworld.com product pages | `params.BATTERY_PACK`, custom-pack scaling |
| Tattu R-Line V5 4S 1300 150C | 156 g, 75 x 38 x 27 mm | tattuworld.com product page | cross-check of g/cell-Ah scaling |
| APC 7x15E | geometry PE0, performance PER3 tables, E-prop limit 150000/D rpm | apcprop.com technical-information/file-downloads | `sq2/bem.py`, `data/apc_geom`, `data/apc_all` |
| Bambu PAHT-CF | density, strength | `data/vendor_docs/Bambu_PAHT-CF_TDS_V3.pdf` | `params.PAHT_CF` |

## Record vehicles (anchors)
| Vehicle | Facts used | Source |
|---|---|---|
| Peregreen V4 (L. & M. Bell) | 657.59 km/h Guinness avg (11 Dec 2025); T-Motor 3120 900 KV; props trimmed ~6 in; spinners +30 km/h; ~12 kW peak; sanded PA6-CF body; spinners tested to 70k, never > 40k rpm | DroneXL 2026-01-04; Notebookcheck 2026-01-16; AirShaper case study |
| Blackbird (B. Biggs) | 626.42 km/h Guinness (8 Dec 2025); 2.0 kg, 40 cm; 14S (2 x 7S custom); APD 200F3 uncooled; APC 7x15 cut to ~6 in; AMAX 2826 rewound; ~34k rpm at 690 km/h (unofficial); motors 76 C | DroneXL 2026-03-02, 2026-09-21 |
| Guinness category | average of runs in opposite directions | guinnessworldrecords.com record 464800 |

## Methods
| Method | Source |
|---|---|
| Turbulent skin friction, form factors, rough-surface cutoff Re | Raymer, *Aircraft Design* eqs 12.27-12.28, 12.30-12.31 |
| Low-AR lift slope (Helmbold/DATCOM), Korn wave drag, Allen-Perkins crossflow | DATCOM; Korn equation; Allen & Perkins NACA TR 1048 |
| Munk moment of slender bodies | Munk 1924 (NACA TR 184) |
| Mass growth allowance 8 % | AIAA S-120A-2015 |
| SIMP topology optimisation | Sigmund 2001; Andreassen et al. 2011 |
| Thin-wall torsion (strut skin) | Bredt-Batho |
| Typical-section flutter (quasi-steady) | Bisplinghoff, Ashley & Halfman, *Aeroelasticity* |

## Assumptions not yet backed by a source or test
See `docs/VERIFICATION.md` "Hardware tests that gate flight": pack IR, actuator time
constant, prop performance above 27k rpm, rotor normal-force slope (0.25/rad), carbon skin
G12, AlSi10Mg allowable (200 MPa conservative bureau value).
