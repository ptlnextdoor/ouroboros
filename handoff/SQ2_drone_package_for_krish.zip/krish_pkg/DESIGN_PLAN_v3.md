# SQ-2 Design Plan v3: from layout model to buildable product

Status: DRAFT, 2026-10-15. Author: lead mechanical design (planning only, no CAD or code changed).
Scope: how an engineering team would turn the SQ-2 layout (`sq2/out/opt_flown.json`,
`cad/src/sq2_cad.py`) into a parametric, assemblable, printable, serviceable vehicle.
Every number below is either taken from the optimizer JSON (marked `[opt]`), a vendor datasheet
(`[vendor]`), a hand calculation shown inline (`[calc]`), or an assumption (`[ASSUME]`).
Assumptions are collected in section 9 and must be closed before CDR.

Baseline geometry used throughout (`sq2/out/opt_flown.json`, scenario `flown`, 590 km/h model):

| Item | Value | Source |
|---|---|---|
| Body length L | 547.1 mm | [opt] `geom.L` (coordinator's "~600 mm" is the SQ-1 number; v3 uses 547) |
| Body max OD | 98.3 mm, 1.6 mm wall | [opt] `geom.fuse_d`; `WALL` in `sq2_cad.py` |
| Nose / tail length | 135.0 / 126.2 mm | [opt] `nose_L`, `tail_L` |
| Pack bay | x 150.0 to 298.9, 2 packs side by side, each 144.9 x 39 x 49 mm, 481 g | [opt] `bay_x0`, `bay_len`, `pack` |
| ESC bay | x 298.9 to ~376, 4x APD 200F3 73 x 33.6 x 13 mm, 36 g | [opt] `esc_bay`; [vendor] |
| Rotor plane x0 / prop x | 339.9 / 327.9 mm, cant 0 deg | [opt] |
| Pod axis radius / offsets | r 160.5 mm, hy 109.0, hw 117.8 (X at 47.2 deg) | [opt] |
| Pod OD / length | 41.2 / 181.2 mm, duct exits 6.9 mm | [opt] |
| Strut | chord 57.1, t/c 0.155 (t 8.8 mm), span 90.7 mm, spar axis x 400.5 (30 % chord) | [opt] |
| Spar | CFRP tube 6 x 4 mm (`SPARS[0]`) | [opt] `design.spar` |
| Fins | 4, span 70.5, root 45.3 mm, at the tail, also landing feet | [opt] |
| Motor | T-Motor V3120, bell D 37.2, 4x M3 PCD 19, 148 g | [vendor] |
| Mass / CG | 3034 g (incl. 8 % growth) / x 302 mm | [opt] |
| Limit speed, q | 1.1 x 590 = 650 km/h -> q = 0.5 x 1.225 x 180.5^2 = 20.0 kPa | [calc] |

## 1. Verdict on the current CAD

The owner is right. `sq2_cad.py` is a good **layout and clash model**; it is not a **design**.
It answers "does the vehicle fit together in space" (106 checks, all passing) and nothing else.
No part in it could be sent to a printer or a machinist and come back assemblable.

### 1.1 What it is vs what a hardware team would have

| Aspect | Current `sq2_cad.py` | Aerospace / consumer-hardware practice | Gap |
|---|---|---|---|
| Model type | Imperative script: solids built, translated, booleaned, exported | Feature tree driven by **user parameters** and a **master skeleton** (layout sketches, reference planes, axes); every part references the skeleton, never another part's geometry | Total. Changing a station means editing Python and re-running; there is no "why" captured in the model |
| Parameters | `WALL`, `TOL` constants plus the optimizer dict read ad hoc | Named, unit-bearing user parameters with a single import point (optimizer JSON -> parameter table), documented ownership | Partial: inputs exist, but no parameter table, no derived-parameter layer |
| Assembly | `cq.Assembly` of overlapping solids with intended "embeds" (strut overlaps skin by 366-552 mm3) | Components with **joints** (rigid, revolute, slider), **joint origins** on real mating faces, interference = 0 by construction; overlaps are errors, not features | Total. "Overlap > 50 mm3 means connected" is a proxy for a joint, not a joint |
| Interfaces | Implicit (a socket bore exists in `strut()`; hub sockets in `spar_cross_frame()`) | **Interface Control Document**: every mating pair has owner, datum, dimensions, tolerance, fastener, load, access | None. Section 3 of this plan is that ICD |
| Fuselage | 1.6 mm revolve, cut at two plain planes for bed fit | Shell + bulkheads/frames at every load introduction (pack ends, ESC bay, spar frame, fin root) + designed joints (spigot/lap, bolts, locating features) | No bulkheads, no joint features, no locating features |
| Internals | Packs and ESCs floating in the bore | Rails, stops, straps, trays, standoffs, cooling path, connector positions, harness routes with bend radii and grommets | None except a 6 mm wire conduit in the strut |
| Purchased parts | Motor as 3 cylinders; ESC as non-watertight vendor mesh; props lofted | Vendor STEP or a controlled envelope solid with the real mounting pattern, keep-outs, and connector locations | Partial (ESC STEP exists but is unusable for booleans, audit V-8) |
| Pod node | Topology-optimised voxel STL, converted triangle-by-triangle to a "solid" | B-rep part with datum faces, the 4x M3 PCD 19 pattern, spar socket, nacelle lugs, machining or AM drawing | Not a CAD part; cannot be dimensioned, toleranced or fixtured. Saves maybe 5 g/node vs a simple CNC node; not worth it |
| Fasteners | 16 M3 motor bolts as cylinders | Full fastener BOM: inserts, screws, pins, straps, adhesives, torque values, thread engagement checks | None (audit V-4, V-5) |
| DFM / DFA | Bed-fit and min-wall checks | Print orientation per part vs load direction, support strategy, shrinkage compensation, insert bosses, fillet radii for stress and for sanding, assembly order with tool access | Minimal |
| Tolerancing | `TOL = 1.0` everywhere | Fit classes per interface: bonded (0.1-0.2 mm gap), sliding (0.3-0.5 mm), located (pin + slot), clamped; print tolerance budget (+-0.2 mm, 0.3-0.6 % shrink PA6-CF) | None |
| Verification | Geometric clash checks | Clash checks **plus** FEA per load case, coupons for printed allowables, proof test, mass/CG rollup fed back to the performance model | Section 6 |

### 1.2 Specific defects that prove the point (all visible in `docs/img/sq2/internal/*.png`)

1. The packs (962 g, the largest mass) sit in a sealed tube. There is no way to install them
   except through an unbonded print joint (audit V-1).
2. The ESCs (green, `internal/render_iso.png`) float in the bore with nothing holding them,
   no heat path, no lead routing (V-3).
3. The hub ring (silver) is a free-floating ring with four stubs; nothing attaches it to the
   shell except an assumed 250 mm3 overlap.
4. The struts enter the skin through a plain overlap. A real strut root sees the pod's
   inertial and aerodynamic load every flight and the landing load on every landing; it needs
   a socket, a bulkhead behind it, and a defined bond or bolt.
5. The two print splits (x 309 and x 499.6) are plain planes with no spigot, flange, bolt, or
   locating feature. Printed PA6-CF butt-bonded across a layer plane is the weakest possible joint.
6. No avionics at all in the CAD: no FC, no ADR board, no GNSS, no antennas, no pitot, no camera.
   The performance model carries them as 82.5 g at x 81 mm, so the nose is assumed to be the
   avionics bay, but nothing holds them.
7. Fins are modelled as solid TPU 95A. TPU (E ~ 25-50 MPa) cannot carry q = 20 kPa:
   a 70 mm fin at 5 deg sees ~19 N [calc: q S CL = 20000 x 0.0024 x 0.4]; tip deflection
   F L^3 / 3EI with I = c t^3/12 = 45 x 3.6^3 / 12 = 175 mm4 is ~300 mm. The fins must be
   PA6-CF with TPU feet, not TPU. The optimizer's 19.5 g fin mass item is therefore wrong too.
8. The spinner retention (bulkhead clamped under the prop nut, 2x M2 pins) exists only as a
   docstring and a 3 mm disc; the prop hub, nut, shaft thread and pins are not modelled (V-4).

### 1.3 What to keep

- The single rotor-to-station frame mapping (`rotor_to_station()`), the geometry function
  (`vehicle.geometry()`) and the optimizer JSON as the **only** source of layout numbers. In v3
  these become the parameter import layer.
- The 106 checks. They move from "the model" to "the CI gate on the model" (section 5.6).
- The spar/hub concept (4 half-spars into a central frame) and the body-ESC decision.
- The spinner-covers-the-bell and inlet-slot concept.

### 1.4 Verdict in one line

Rebuild as a top-down parametric Fusion assembly (skeleton -> components -> joints -> features)
with an ICD, keep CadQuery as the automated check layer, and treat the current script as the
geometry spec it already is. Estimated effort: 3-4 weeks of one engineer plus the socket add-in
(section 7).

## 2. Structural architecture options

### 2.1 Does a one-piece body fit the printer? (quantified)

Bambu H2D: 325 x 320 x 325 mm single nozzle; **300 x 320 x 325 mm with both nozzles** (needed
for PA6-CF + TPU in one print) [ASSUME A1: dual-nozzle X loss of 25 mm, from Bambu's published
spec; confirm on the machine]. Vehicle envelope `[opt]`:

| Volume | x (length) | y | z | Fits H2D? |
|---|---|---|---|---|
| Body alone | 547 | 98 | 98 | **No** (547 > 325) |
| Body + 4 struts + 4 pods + spinners | ~547 (spinner tip x 281, pod tail x 521, body 0-547) | 2 x (109.0 + 20.6) = **259** | 2 x (117.8 + 20.6) = **277** | **No** in x; y, z fit (259 < 300, 277 < 320) |
| Body + struts only (no pods) | 547 | 2 x (109.0 - 25) ~ 170 | ~190 | No in x |
| Any 320 mm long slice of the above | 320 | 259 | 277 | **Yes**, standing on end, 5 mm Z margin |

Diagonal placement: for a cylinder of diameter d = 98 mm along the box space diagonal
(diag = 560 mm, direction cosines 0.580 / 0.571 / 0.580), the axis-x extent is
L x 0.580 + 98 x 0.814 <= 325, so **L <= 422 mm** [calc]; the nose/tail taper buys ~40-50 mm
more, so ~460-470 mm at most. Still 80 mm short of 547, and a 1.6 mm shell printed along the
diagonal has supports on half its skin, layer stairs at 55 deg on the other half, and layer
lines crossing the spar frame at a slant. **Rejected.**

Shrinking the vehicle to fit: a standing print needs L <= 325 mm. The irreducible stack is
pack bay 145 + ESC bay 77 + spar frame/strut root zone ~60 + avionics ~60 + nose/tail
fineness for drag (nose_L + tail_L = 261 `[opt]`) = ~600 mm; even with packs end to end in a
69 mm body the optimizer's own fineness choice lands at 547. A 325 mm vehicle is a different
(slower) design. **Rejected** for this record attempt.

Ways a literal one-piece 547 mm body can exist:

| Route | Build volume | Material | Fit | Finish | Cost / lead | Verdict |
|---|---|---|---|---|---|---|
| SLS bureau (EOS P396 class, 340 x 340 x 600) | 340 x 340 x 600 | PA12, PA11-CF, PA12-GB | Yes, body + struts + pods in one shot (547 x 259 x 277) | Grainy, Ra 10-15 um; needs 2 coats filler + sanding | ~USD 400-900 per body, 5-10 days [ASSUME A2] | Viable fallback; no TPU co-print; one crash = one body |
| MJF bureau (HP 5200, 380 x 284 x 380) | 380 x 284 x 380 | PA12, PA11 | No (547 > 380) | | | No |
| Large-format FDM (Modix Big-60 600x600x660, Elegoo Giga 800x800x1000, Prusa XL 360^3 no) | >= 600 Z | PA6-CF needs enclosure + hardened nozzle | Yes on Modix/Giga class | Same as H2D if tuned | Machine access needed; Giga unenclosed = PA6-CF warps [ASSUME A3] | Only if a local one is available |
| Bambu H2D, standing, **vehicle redesigned to 320 mm** | 300 x 320 x 325 | PA6-CF + TPU | Yes | Best | n/a | Different vehicle, rejected above |

Conclusion: on the owner's H2D the "one piece" has to be **one piece per 320 mm**, i.e. a
sectioned body with designed joints. Multi-material (TPU interlaced with PA6-CF) is still
available **inside each section**: TPU nose tip, TPU landing feet, TPU pack-bay liner strips
and TPU avionics grommets can all be printed in the same job as their PA6-CF section.

### 2.2 Options compared

Load cases used for the comparison (all `[calc]` from `[opt]` numbers, FS 1.5 on limit):

| Case | Magnitude | Where it enters |
|---|---|---|
| L1 Max static thrust (hover/climb) | 4 x 31.5 N = 126 N total (T/W 4.23 at 8 m/s) | Motor face -> pod node -> spar -> hub frame -> shell |
| L2 Thrust at V_max | 4 x 13.7 N | same |
| L3 4 g pull-up at V_L, +5 deg gust | Pod + strut inertia 4 x 9.81 x 0.25 kg = 10 N per pod; strut/pod aero lift ~25 N per pod; spar root sigma 40 MPa `[opt]`; body inertia: packs 4 x 9.81 x 0.962 = 38 N on pack rails | Spar, strut root socket, hub-to-shell ring, pack rails |
| L4 Rotor gyroscopic, 4 rad/s pitch rate | H = I w = 4e-5 kg m2 x 2835 rad/s = 0.11 N m s -> 0.45 N m per rotor at the motor mount | Motor bolts, pod node (negligible vs L1) |
| L5 Landing, tail-sitter, 20 g vertical | 3.1 kg x 196 m/s2 = 610 N on the four feet; pack inertia 189 N on the aft pack stop; ESC inertia 4 x 7 N; avionics 16 N | Fins/feet -> tail section -> aft joint -> centre section; pack aft bulkhead |
| L6 Aero pressure on skin and hatches | q = 20 kPa; local Cp -0.3 to +1.0; hatch 150 x 60 mm sees up to 55 N suction `[calc 0.3 x 20 kPa x 0.009 m2]` | Hatch locks, shell between frames |
| L7 Prop burst / blade-off (containment not required; survival of the vehicle not required) | n/a | Spin test gate instead |

| Criterion | **A. One-piece multi-material print** (TPU nose/belly + PA6-CF body + struts + fins) | **B. 3-section printed body, designed joints** (recommended, see 2.3) | **C. Printed aero skin over CFRP/Al internal spine** |
|---|---|---|---|
| Feasibility on H2D | **Not possible** at L 547 (2.1). Possible only via SLS bureau (no TPU) or large-format FDM | Yes: nose 0-150, centre 150-470 (320 mm), tail 470-547, each standing | Yes, skin segments are short; spine is a bought tube/plate |
| Load path L1/L3 (thrust, manoeuvre) | Spar -> integral strut -> shell hoop; fine if struts are integral and printed with fibres along span (only true if printed lying down, which needs supports on every aero face) | Spar -> 7075 hub frame -> bonded ring to the centre-section shell + 2 frames; struts are fairings, carry no primary load | Spar -> hub frame bolted to the spine; shell carries nothing |
| Load path L5 (landing) | Fins integral; impact into a monolithic shell | Fins integral with the tail section; TPU feet; aft joint carries 610 N in compression through a 40 mm spigot (bearing area 2 x pi x 45 x 20 = 5600 mm2 -> 0.11 MPa, trivial) | Spine takes it; skin must not be loaded (needs soft mounts) |
| Mass (shell + frames + joints, body only) | ~270 g shell + 60 g frames (frames still needed inside); SLS PA12 at 1.6 mm similar | 270 g shell + ~65 g frames/rails + ~30 g joints/hatch/inserts = **~365 g** (+95 g vs model's 270 g item) | 270 g skin (could thin to 1.2 mm: -65 g) + 80 g CFRP keel 2 x 49 x 547 mm (or 150 g in 7075) + 40 g brackets = **~325-395 g**, and OD grows by 0-16 mm if the keel is a tube |
| Bending stiffness (body, about y) | Shell: E 5 GPa [ASSUME A4, PA6-CF XY], I = pi r^3 t = 5.6e5 mm4, EI = 2.8e9 N mm2 | Same shell, reduced ~20 % at each joint unless spigot >= 25 mm; joints inside frames restore it | Keel plate 2 x 49 mm CFRP edgewise EI = 2.0e9, weak in the other plane (t^3); shell still does the work |
| Repairability | Any crash or print flaw = whole body | Damaged section reprinted alone (nose is the usual crash victim); pods are separate consumables | Skin segments cheap; spine survives most crashes |
| Print orientation / supports | Standing impossible; lying needs supports under 2 struts, 2 fins and half the belly | All three sections standing on end, **no supports** on any outer surface; struts separate, printed span-vertical | Skin segments standing, no supports |
| Surface finish to ks <= 10 um | Supports scar ~30 % of wetted area; SLS needs filling everywhere | Standing print: 0.2 mm layer stairs only, filler + 600 grit over 100 % as planned; two circumferential joint lines to fill (section 3.10) | Same as B plus segment lines |
| Build time (H2D, PA6-CF, 0.16-0.2 mm) | n/a (bureau 5-10 days) | Nose 4-6 h, centre 14-20 h, tail 3-4 h, 4 struts 4 h, 4 nacelles 6 h, 4 spinners 2 h: **~35-40 h** [ASSUME A5] | ~30 h printing + machining/ordering the spine |
| Multi-material use | Full | TPU nose tip, TPU feet, TPU bay liners, grommets, all co-printed per section | Same as B |
| Risk | High: cannot be built on-site; bureau turnaround kills iteration; no TPU; SLS PA12 stiffness 1.7 GPa (half of PA6-CF) | Low-medium: joint design must be proven (coupon + proof test); 5 mm Z margin on the centre section (parametric check) | Medium: mass creep, OD growth if tubular, two structures to analyse |
| Record-vehicle precedent | Peregreen V4 (smaller vehicle, fits an H2D) | Blackbird-style sectioned bodies; most speed quads | Common on heavier UAVs, not on speed quads |

### 2.3 Recommendation: **Option B**, with C's hard points where loads concentrate

Three printed PA6-CF sections standing on the H2D, joined by spigot-and-bolt joints that sit
inside internal frames, one belly hatch for the packs, separate printed strut fairings over
CFRP spars into a machined 7075 hub frame, CNC (not topology-optimised) pod nodes, separate
nacelles. Multi-material only where TPU earns its place (nose tip, feet, liners, grommets).

Why not A: it cannot be printed on the owner's machine at this length, and the one route that
can (SLS bureau) loses the TPU, the iteration speed and the fibre stiffness. Why not C: the
shell is already the stiffest beam available for its mass; a spine adds 50-120 g and, as a
tube, 16 mm of OD (fuselage drag item +~15 %). Where C is right (concentrated loads at the
spar and the pack stops) B uses machined and composite parts anyway.

Probability this is the right call: ~80 %. Most likely way it is wrong: the centre section
joints end up heavier or less stiff than estimated and the vehicle needs a 4th split, in which
case the fix is to move the forward split to x 120 and shorten the nose section, not to change
architecture. Second failure mode: PA6-CF warp on a 320 mm standing shell; mitigation is a 3 mm
brim, 60 C chamber, and a dry-box (PA6 absorbs 2-3 % water in a day).

What the owner's one-piece intent still gets: the **centre section is one monolithic part**
containing the pack bay, ESC bay, spar frame seat and all four strut sockets, so every primary
load path is inside one print; the nose and tail are the crash-replaceable ends.

## 3. Internal layout and interface control document (ICD)

### 3.1 Station layout (x from nose tip, mm, `[opt]` unless noted)

```
x:   0      50      150        299      376  394-406   440   470      547
     |TPU tip|  NOSE  | PACK BAY  | ESC BAY |  | HUB |strut|  TAIL   |
     |pitot  |avionics|2x 7S side |4x 200F3 |  |frame| root|fins+feet|
     |RX ant |tray    |by side    |2 trays  |  |7075 |     |VTX ant  |
     ^ J1 nose joint (x150)                        ^ J2 tail joint (x470)
```

- **Nose section** (x 0-150, PA6-CF + TPU tip x 0-50): avionics tray, pitot, RX antennas, camera.
  Removable; its removal is the pack access (no belly hatch, see 3.3).
- **Centre section** (x 150-470, one print, 320 mm): pack bay with rails, pack aft bulkhead
  with blind-mate bullets, ESC trays, hub frame seat, 4 strut sockets. Monolithic.
- **Tail section** (x 470-547): 4 integral fins (PA6-CF), TPU feet, VTX antenna in a foot.
- **Pods** (4): CNC 7075 node, motor, front + rear nacelle halves, spinner-nut, prop.
- **Struts** (4): CFRP 6 x 4 spar (primary), printed PA6-CF fairing (secondary, skinned).

Design change vs optimizer: the fuselage formula `fuse_d = hypot(2w, h) + 2 x 1.6 + 3.0`
leaves 1.5 mm radial for rails and liner. Recommend the clearance term become a user parameter
`pack_clearance` = 5.0 mm (fuse_d 98.3 -> 100.3, fuselage CdA +~1.5 %, ~ -1 km/h) [ASSUME A6].

### 3.2 Interface control table

Fit classes: **B** bonded (0.1-0.2 mm gap, 3M DP420 or Loctite EA 9394 unless stated),
**S** sliding (0.3-0.5 mm), **L** located (pin/key + clearance), **C** clamped/bolted.
Print tolerance budget: +-0.2 mm on any dimension < 100 mm, +0.3 % shrink on PA6-CF
compensated in the slicer; all mating bores are **reamed or drilled after printing**
(spar bores, insert holes). Insert: Ruthex RX-M3x5.7 (brass, OD 4.0, hole 4.0 mm, boss >= 7 mm OD)
or CNC Kitchen M3 x 5.7 equivalent; M2 inserts RX-M2x4.0 (hole 3.2 mm). [ASSUME A7: pull-out
of M3 insert in PA6-CF >= 300 N; measure on coupon, section 6.]

| ID | Interface (A to B) | Datum / location | Geometry | Fastener / joining | Fit | Design load (limit, FS 1.5 applied in check) | Access / removal |
|---|---|---|---|---|---|---|---|
| IF-01 | Nose section to centre section (joint J1) | Plane x = 150, body axis, clocking key at 0 deg (dorsal) | Male spigot on nose: OD = centre ID - 0.3, length 25 mm, wall 1.6 mm + internal ring frame 4 mm thick at the spigot root; 1 key 3 x 3 x 10 mm; OML step 0 (spigot is inside) | 3x M3 x 6 countersunk (DIN 7991 A2) at 0/120/240 deg, radial, into RX-M3 inserts in 3 bosses on the spigot (boss 7 x 8 mm); heads 0.3 mm below OML, filled with wax or 1-layer Kapton for the run. Alternative: bayonet 3-lug 30 deg + 1 M2.5 safety | S + C | Nose inertia 20 g x 0.12 kg = 24 N axial; pack forward stop 16 N (1.7 g decel); aero ~10 N; screw shear 180 N side load / 3 = 60 N each (M3 A2 shear ~1.5 kN) | Remove 3 screws, pull nose forward; one harness connector (IF-13) and the pitot tube come with it |
| IF-02 | Tail section to centre section (joint J2) | Plane x = 470, clocking key at 0 deg | Male spigot on tail, length 25 mm, OD = centre ID at x 470 - 0.3 (body OD 72.0 at x 470 by the `body_profile()` formula, so spigot OD ~68.5); tail section has an internal ring at the spigot root; 4 fin roots start 20 mm aft of the joint | 4x M3 x 6 countersunk radial at 45/135/225/315 deg into inserts in the spigot bosses + bonded with DP420 (tail is not routinely removed; bonding doubles as the OML seam filler) | S + C + B | Landing 610 N compression through the spigot shoulder (bearing 0.11 MPa); side load 180 N / 4 screws; rebound 10 N tension | Only for repair: cut bond, remove 4 screws |
| IF-03 | Packs to pack bay (rails and retention) | Bay x 150-299, bay floor = internal flat lands at z = +-24.5 (dorsal/ventral), pack centre y = +-20 | 2 integral rails per land: 2 mm wide x 3 mm high ribs, 140 mm long, pack sits between rib pairs with 0.5 mm side play; TPU 95A liner strips 1 mm (co-printed) on both lands; aft stop = pack bulkhead at x 299 (IF-04); forward stop = nose ring frame (IF-01) with 5 mm PU foam pad (ρ 40 kg/m3) compressed 2 mm; no strap needed (axially captive between bulkheads, laterally captive by rails and bore) | Captive | Landing 20 g: 189 N aft onto the pack bulkhead (bulkhead 3 mm PA6-CF, area 95 x 95 less cutouts; bending stress < 5 MPa); 4 g manoeuvre 38 N lateral into rails (rib shear 38 N / (2 x 140 x 2 mm2) = 0.07 MPa) | Packs slide out forward after nose removal; no tools |
| IF-04 | Pack electrical to vehicle bus (blind mate) | Pack bulkhead x 299, bullet axes along x at y = +-20, z = 0 | Each pack rear face carries 2x 8 mm gold bullets (male, Amass AS150-class pins, 150 A cont. / 280 A for 30 s [ASSUME A8]) on a 2 mm G10 plate potted to the pack; bulkhead carries 4x 8 mm female sockets in a printed PA6-CF carrier (bullet spacing 14 mm, lead-in chamfer 2 mm); packs are keyed (rails asymmetric, 3 mm offset) so they cannot be inserted swapped; series jumper (pack1 + to pack2 -) is a 12 AWG link on the bulkhead's aft face | L + mate force ~15 N per bullet | 280 A bus, 25 s; contact resistance 0.3 mOhm x 4 = 1.2 mOhm (0.3 V, 90 W, acceptable) | Mates on pack insertion; balance leads (JST-XH 7S) exit the pack front face to a parking socket on the nose ring |
| IF-05 | ESC trays to centre section | ESC bay x 301-376; 2 trays, each at z = +-14 (stacked flat, 2 ESCs side by side per tray at y = +-18) | Tray = 1.0 mm 6061 plate 76 x 70 mm (14 g) with 2 ESCs bonded flat-side down with 3M 8810 thermal tape (adds ~13 J/K per ESC of thermal mass, ~5 K benefit; primary purpose is retention). Tray edges slide into 2 integral rails in the bore (1.2 mm slot) from the front; tray aft end has 2 tabs that screw M3 x 6 into the hub frame's forward bosses (IF-06) | S + C | ESC inertia 4 x 36 g x 20 g = 28 N on the rails; tape shear 28 N / 2 x 2450 mm2 trivial | From the front with a 250 mm T-handle 2.5 mm hex after packs are out; ESC harness connectors face forward |
| IF-06 | Hub frame to centre section | x 394-406, frame plane normal to body axis at the spar axis x 400.5; frame clocked to the 4 strut sockets by its own 4 socket bosses | 7075-T6 waterjet plate 6 mm thick "X + ring": ring OD = bore - 0.2, 4 radial socket bosses bored 6.05 +0.05 mm, 28 mm deep, starting at r = 10.4 mm (`spar_start_radius`); 2 forward bosses tapped M3 for the ESC trays; 4 cutouts for the harness. Mass target 28 g (model carries 80 g; BOM says 22 g: reconcile, [ASSUME A9]) | Ring bonded to the bore with DP420 over 6 mm x pi x 95 = 1790 mm2 (DP420 shear 25 MPa, PA6-CF side ~8 MPa surface-limited: capacity ~14 kN) + 4x M3 x 5 radial screws through the shell into M3 tapped holes in the ring (anti-peel, assembly location) | B + C | Spar root moment per pod (L3): M = 40 MPa x I/c = 40 x 51 / 3 = 0.68 N m; thrust 31.5 N x 4 in; landing moment negligible | Not removable |
| IF-07 | Spar to hub frame socket | Socket axis radial at 47.2 deg dihedral clocking, depth 28 mm | CFRP tube 6.0 x 4.0 mm, pultruded (Rock West 23048 or DragonPlate equivalent, [ASSUME A10 tensile 1.2 GPa, E 120 GPa]), abraded + degreased, bonded with DP420 (or EA 9394 for 80 C service) | B | Bond shear: M/(depth) coupling: 0.68 N m / 0.028 m = 24 N couple + 31.5 N thrust shear over pi x 6 x 28 = 528 mm2 -> < 0.2 MPa | Not removable |
| IF-08 | Spar to pod node socket | Node socket on pod axis plane, x_spar - x0 = 60.6 mm aft of motor face (= body_len 38.6 + 22 [`sq2_cad`], verify) | CNC 7075 node (replaces the AlSi10Mg topology part): 38 mm OD disc 4 mm thick (motor flange) + 22 mm long boss with the 6.05 mm socket 25 mm deep + 2 nacelle shoulder rings (IF-10) + 2 phase-lead slots. Mass target 12 g | DP420, 25 mm engagement (4.2 x OD) | B | Same as IF-07 | Not removable |
| IF-09 | Motor to pod node | Motor base face = node datum A; shaft axis = datum B; 4x M3 on PCD 19 `[vendor]` | Node flange 4 mm with 4x 3.2 mm through holes on PCD 19 + 1 centre bore 12 mm for the shaft/bearing boss; phase leads exit the motor base through a 10 x 4 mm slot in the node | 4x M3 x 8 SHCS 12.9, Loctite 243, 1.2 N m, into the motor's tapped M3 holes (thread engagement 4 mm = 1.3 d; check vendor drawing) | C | Thrust 31.5 N / 4 = 8 N tension; gyro 0.45 N m / 0.019 m = 24 N; preload 1.2 N m -> ~1.3 kN per bolt: joint never separates | Remove rear nacelle, 4 bolts |
| IF-10 | Nacelle halves to pod node | Circumferential seam at the strut station (x_spar), i.e. under the strut root fillet; node shoulder ring OD = nacelle ID - 0.2 | Front nacelle (lip to x_spar, slides on from the front over the node; lip ID 38.0 lets the bell pass) and rear nacelle (x_spar to tail, slides on from the rear); each has a half-cutout of the strut profile + 2 mm; each sits on a 6 mm wide node shoulder and takes 2x M2 x 4 countersunk screws into M2 tapped holes in the node (90 deg from the strut) | S + C | Nacelle aero drag ~2.2 N `[opt pods 7 cm2 / 4]`; inertia 32 g x 20 g = 6 N | Rear half off: 2 screws; front half off: 2 screws + spinner/prop |
| IF-11 | Strut fairing to spar, to centre section, to nacelle | Spar axis at 30 % chord; fairing root sits in a printed socket in the centre section 8 mm deep (NACA profile + 0.3 mm), tip sits in the nacelle cutouts | Fairing = PA6-CF print (1 mm wall + spar sleeve) printed span-vertical, skinned with 1 ply 200 gsm 2x2 twill CFRP (`skin_ply`) wet layup over the print, sanded. Bonded to the spar at root (20 mm) and tip (20 mm) only, with 3M 2216 (flexible, so the fairing does not take spar bending); root socket bonded with DP420 fillet 3 mm radius on the OML | B | Fairing aero: 5.4 cm2 x 4 struts -> 2.7 N per strut; torsion from Munk moment on the pod reacted by the spar, fairing sees only its own | Not removable (pod + strut + spar is one bonded sub-assembly) |
| IF-12 | Harness through strut | Conduit at 60 % chord, 7 mm bore (was 6: 3x 16 AWG silicone OD 2.9 = 20 mm2 vs 38 mm2 bore, 52 % fill) | Conduit continues through the node (slot) and through the centre-section strut socket floor into the bore via a 7.5 mm hole with a co-printed TPU grommet; phase leads 16 AWG, 3.5 mm gold bullets at the ESC end (or soldered) | S | Chafe only | Pull-through; leads replaced with the pod |
| IF-13 | Avionics tray to nose section | Tray rails at z = +-18 in the nose bore from x 55 to 145; tray datum = nose ring frame face | PA6-CF tray 90 x 50 mm, 1.5 mm; carries FC (30.5 pattern, M3) on 4x silicone grommets (8 x 3 mm, 50 A) + brass M3 standoffs 6 mm, ADR board (60 x 38, 4x 3.2 holes) on the same grommet type at its corner pattern, GNSS module, RX, current sensor, bus cap board; tray slides in from the aft (open) end of the nose and screws 2x M3 x 6 to the nose ring frame | S + C | 82 g x 20 g = 16 N; vibration isolation target: grommet stack f_n ~ 60-80 Hz, below 1P at 27 krpm (450 Hz) by > 5x [ASSUME A11] | Out with the nose; one JST-GH 6 + one XT30 (FC power) connector to the centre section |
| IF-14 | Antenna windows (CF is RF-opaque) | GNSS: dorsal x 70-100; RX 2.4 GHz: TPU nose tip; VTX 5.8 GHz: one TPU foot | GNSS patch 25 x 25 under a 1.6 mm **unfilled** TPU 95A window 35 x 35 (co-printed into the PA6-CF nose: TPU loss at 1.575 GHz < 0.5 dB [ASSUME A12]); 2x RX dipoles (ELRS 2.4, 31 mm) inside the TPU tip; VTX dipole (5.8 GHz, 13 mm) in a TPU foot with u.FL/MMCX pigtail up the fin root channel (2 x 3 mm, printed) | co-printed | q on window: 20 kPa x 0.0012 m2 = 24 N spread; TPU window bonded by the print | Replace with the section |
| IF-15 | Pitot and static to ADR board | Pitot on the body axis, tip 40 mm ahead of the nose tip; statics at x 120, +-90 deg from dorsal | Pitot 3.0 x 2.0 mm stainless tube, 70 mm long, press fit through the TPU tip into a printed boss in the PA6-CF nose; 2x static 0.8 mm holes into a printed ring manifold; both to ADR U4 ports via 2 mm ID silicone tube | press + silicone | 20 kPa dynamic; tube drag ~0.05 cm2 | Replace tube by pulling it forward |
| IF-16 | Fins and feet to tail section | Fins integral (printed in the tail section, planes through the axis, clocked 45 deg from the pod X = `[opt]` fin clocking) | Fin NACA 0008, root 45.3, span 70.5 mm `[opt]`, PA6-CF 2 walls + 20 % gyroid; TPU 95A feet co-printed on the fin tip trailing corners, 8 x 8 x 10 mm, protruding 5 mm aft of the body tail end so the body never touches the ground; tip-over half-angle atan(70/245) = 16 deg [calc, flag: marginal in wind] | integral | Landing 610 N / 4 = 153 N per foot into a fin tip: fin as a column, buckling check (section 6) | n/a |
| IF-17 | Main power bus and bus capacitor | Aft face of the pack bulkhead (x 299-301) and ESC trays | Bus: 2x 10 AWG silicone (or 2 x 12 AWG per polarity) from the bulkhead sockets to the ESC trays, max 120 mm; 4x 470 uF 63 V low-ESR (Rubycon ZLH or Panasonic FM) across the bus at each tray; current sensor: 300 A hall (e.g. Allegro ACS772 module) in the - lead at the bulkhead | solder + strain relief (TPU clip) | 280 A, 25 s: 10 AWG at 280 A for 25 s: dT ~ 25 K [ASSUME A13] | Via the front after pack removal |
| IF-18 | Arming / charging | Belly x 160, 10 mm TPU-grommeted hole | Arming loop XT30 on a 40 mm lead; charging with packs out (balance leads) | n/a | n/a | External |
| IF-19 | Prop and spinner to motor shaft | Motor shaft M5 thread (V3120: 5 mm shaft, M5 prop nut `[vendor]`, confirm thread length >= 12 mm); prop hub face = datum | **Spinner-nut** (Peregreen/Blackbird practice): CNC 7075 or 2024 spinner, ogive 1.3 x D, D = bell + 2 x 1.6 + 0.8 = 41.2 mm, base skirt covering the bell with 0.4 mm running gap to the nacelle lip; internal M5 thread 8 mm deep in a 10 mm boss at the base; the spinner IS the prop nut and clamps the prop hub against the motor's shaft shoulder/washer; 2x 2 mm dowel pins in the spinner base engage 2 holes drilled in the prop hub (anti-rotation under motor decel). Hollow, wall 1.0 mm, mass target 9 g (model: 5.8 g printed) [ASSUME A15] | M5 thread, 2.5 N m, no Loctite (CW/CCW: shaft rotation tightens on 2 motors; the other 2 need **left-hand** thread spinners or a secondary M2 grub screw: decide per motor rotation) | C | Centrifugal: spinner at 31 krpm, r 20 mm: a = 2.1e5 m/s2; 9 g -> hoop stress in a 1 mm 2024 wall ~ 7 MPa, trivial; prop clamp preload 2.5 N m -> ~2.5 kN | Spinner off = prop off, one 17 mm socket on 2 flats |
| IF-20 | Blade root clearance in spinner skirt | Blade roots pass through 2 slots in the skirt | Slots = swept blade section at 0 deg pitch + 0.5 mm all round (as `sq2_cad.spinner()`), edges radiused 0.5 mm | n/a | n/a | The skirt rotates with the prop so the slot is static relative to the blade | n/a |

### 3.3 Why no belly hatch, and the hatch spec if one is wanted

The nose joint already opens the full 95 mm bore; packs, ESC trays and avionics all pass through
it. A hatch would add a second OML seam (each seam ~0.2-0.4 cm2 of excrescence drag at 20 kPa
[ASSUME A14]), 10-15 g of lock hardware, and a stiffness cut in the shell. If the owner wants
hands-on ESC access without pulling packs: dorsal hatch x 305-375 x 50 mm wide, 1.6 mm PA6-CF
lid with a 4 mm lip all round sitting on an integral 2 mm ledge, forward tongue + 2x M3 x 6
countersunk aft into inserts; rated 55 N suction (Cp -0.3) with FS 3. Quarter-turn (Dzus/Camloc)
fasteners rejected: 4-7 g each and they need a 6 mm thick receiver.

### 3.4 Keeping the OML smooth across every joint

- Every joint is a male spigot **inside** the shell with a 0.3 mm radial step at the OML
  designed to zero (spigot OD = ID - 0.3, OML continuous). After assembly: a 0.2 mm bead of
  lightweight filler (3M Acryl-Red or Bondo glazing putty) in the seam, sanded flush, clear coat.
  Nose joint (removable) gets 25 um Kapton tape over the seam for the run, as record teams do.
- Screw heads: countersunk 0.3 mm below the OML, filled with microcrystalline wax for the run.
- Strut root and nacelle seams: 3 mm filleted bond bead (Hoerner: fillets cut T-junction
  interference drag 50-70 %, `ARCH_STUDY` lever 4), sanded.
- Antenna windows: co-printed, flush by construction; the TPU surface sands poorly, so the window
  is printed 0.1 mm proud and the PA6-CF around it is sanded to meet it.
- Finish spec stays R11: 2 coats 2K high-build primer, wet-sand 400 -> 600 -> 800, 1 coat 2K
  clear, measured on a coupon printed with the same profile (profilometer ks <= 10 um).

## 4. Assembly sequence and fastener / insert BOM

### 4.1 Sub-assemblies (build in parallel, then integrate)

**SA-1 Pod (x4), ~1 h each after parts are in hand**
1. Deburr CNC node; check 6.05 socket with a 6.00 pin gauge; tap M2 x 4 nacelle holes if not done.
2. Feed the 3 motor phase leads through the node slot; bolt motor to node, 4x M3 x 8 SHCS 12.9,
   Loctite 243, 1.2 N m, cross pattern. Check shaft runout < 0.03 mm with a dial gauge.
3. Cut CFRP spar to length (r_end - r0 = 160.5 - 1 - 10.4 = 149 mm `[opt]`, +0 / -0.3). Abrade
   both ends 25 mm with 240 grit, wipe IPA. Mark the 25 mm node-end depth.
4. Mix DP420, coat socket and spar end, insert to the mark, rotate 1/4 turn, wipe excess, fixture
   square (print a jig: node on a V-block, spar in a 6.05 hole 100 mm away). Cure 24 h at 23 C or
   2 h at 65 C.
5. Slide the strut fairing over the spar from the free end (conduit toward the trailing edge),
   push the phase leads through the conduit, bond the tip 20 mm with 2216 into the nacelle
   cutout zone; do not bond the root yet.
6. Slide the front nacelle on from the front over the node shoulder (phase leads inside),
   2x M2 x 4 csk; slide the rear nacelle on from the rear, 2x M2 x 4 csk.
7. Fit the prop and spinner-nut (IF-19) only after the spin test (section 6).

**SA-2 Centre section, ~3 h**
1. Post-print: dry 4 h at 80 C (PA6-CF); ream the 4 strut socket floors' 7.5 mm harness holes;
   drill/ream the 4x M3 hub-ring screw holes through the shell at the marked dimples; install
   RX-M3 inserts in the 3 nose-joint bosses (from inside, soldering iron 240 C, insert press
   jig) and 4 tail-joint bosses.
2. Install the 4x 8 mm female bullets into the pack bulkhead carrier from the aft side; solder
   the 12 AWG series link and the 2x 10 AWG bus leads; fit the current-sensor module to the
   bulkhead's aft face (2x M2.5 x 6 into inserts).
3. Hub frame: dry-fit from the aft end (body OD is still 98.3 at x 406; the taper starts at
   x 421, so the ring passes through the full bore from the aft opening before the tail is
   fitted: **parametric check** `o_L - o_tail_L >= hub aft face`); clock to
   the strut socket bosses with a printed alignment jig (4 dummy 6 mm pins through the sockets
   into the ring bosses); bond with DP420 on the ring periphery, fit the 4x M3 x 5 radial
   screws as clamps, cure 24 h, pull the pins.
4. Insert the two ESC trays (ESCs taped, bus caps soldered, phase bullets fitted) from the front
   along their rails; screw the 2 tabs each M3 x 6 into the hub frame's forward bosses with a
   250 mm T-handle; connect the bus leads (solder or 8 mm bullets) to the bulkhead.
5. Bond the co-printed TPU liner strips if the slicer could not co-print them (fallback: 1 mm
   TPU sheet, CA).

**SA-3 Nose section, ~1.5 h**
1. Dry; install 2x RX-M3 inserts in the ring frame for the tray; fit the pitot tube through the
   TPU tip into its boss (press, 1 drop CA at the boss); run 2 mm silicone tubes from pitot and
   static manifold to the tray position.
2. Build the avionics tray on the bench: grommets + standoffs, FC, ADR, GNSS, RX (antennas
   routed forward into the TPU tip channels), camera at the tip (if carried), bus cap board,
   harness to one JST-GH 6 (signals) + XT30 (power) at the tray's aft edge.
3. Slide the tray into the nose from the aft end, 2x M3 x 6 into the ring frame.

**SA-4 Tail section, ~0.5 h**
1. Dry; install 4x RX-M3 inserts in the spigot bosses; route the VTX pigtail up the fin channel
   into the TPU foot; fit the VTX dipole; bond the foot cap (TPU, CA).

### 4.2 Final integration (technician step list, ~4 h)

1. Centre section on a V-block cradle (printed, 2 pieces), nose end toward the bench front.
2. Pod sub-assembly LU: feed the 3 phase leads through the strut-root harness hole and grommet;
   coat the spar's hub end 28 mm and the fairing root 8 mm with DP420; insert the spar through
   the strut socket into the hub frame socket to the hard stop; seat the fairing root in its
   NACA socket; wipe; check pod axis parallel to the body axis with the alignment jig (laser or
   two straightedges, target +-0.3 deg, cant per `[opt]` 0 deg). Repeat RU, LD, RD. Cure 24 h
   with all four jigged simultaneously.
3. Fillet all four strut roots and the nacelle seams with DP420 + microballoons, 3 mm radius,
   using a 3 mm radius tool; sand after cure.
4. Inside the bore: connect the 12 phase leads to the ESC bullets (ESC 1 = LU ... per the FC
   motor map, label each), dress with TPU clips, verify no lead touches the pack rail zone.
5. Tail section: coat the spigot with DP420 (or leave dry for first flights), align the key,
   push home, 4x M3 x 6 csk. Fill the seam.
6. Packs: slide each into its keyed rails until the bullets mate (feel the detent); check
   with a meter at the arming loop that the bus reads 14S (~58 V charged).
7. Nose: connect JST-GH 6 and XT30 to the centre section's forward pigtails, align the key,
   push the spigot home, 3x M3 x 6 csk. Kapton the seam. Fit the arming loop.
8. Props + spinner-nuts (after spin test): 2.5 N m, check rotation direction vs thread hand.
9. CG check: balance on a knife edge at x 302 +- 3 mm `[opt]`; shift the avionics tray mass or
   add ballast in the TPU tip (cavity provided, up to 20 g) to trim.
10. Pre-flight: motor direction test with props off; pitot leak check (syringe, 30 s hold);
    range check with the CF body between TX and RX; ESC telemetry temperature baseline.

Pack swap at the field: 3 screws, pull nose, pull 2 packs, push 2 packs, push nose, 3 screws,
Kapton. Target < 5 min.

### 4.3 Fastener, insert and adhesive BOM

| # | Item | Spec / part | Qty (+spares) | Where (IF) | Mass each (g) | Total (g) |
|---|---|---|---|---|---|---|
| F1 | M3 x 8 SHCS 12.9 black | DIN 912 | 16 (+8) | IF-09 motor | 0.9 | 14.4 |
| F2 | M3 x 6 countersunk A2 | DIN 7991 | 7 (+8) | IF-01 (3), IF-02 (4) | 0.5 | 3.5 |
| F3 | M3 x 6 SHCS A2 | DIN 912 | 6 | IF-05 trays (4), IF-13 tray (2) | 0.6 | 3.6 |
| F4 | M3 x 5 low-head A2 | ISO 7380 | 4 | IF-06 hub clamp screws | 0.5 | 2.0 |
| F5 | M2 x 4 countersunk A2 | DIN 7991 | 16 (+8) | IF-10 nacelles | 0.15 | 2.4 |
| F6 | M2.5 x 6 SHCS A2 | DIN 912 | 2 | current sensor | 0.3 | 0.6 |
| F7 | Heat-set insert M3 x 5.7, OD 4.0 brass | Ruthex RX-M3x5.7 | 9 (+10) | IF-01 (3), IF-02 (4), IF-13 (2) | 0.35 | 3.2 |
| F8 | Heat-set insert M2.5 x 4 | Ruthex RX-M2.5x4 | 2 | current sensor | 0.2 | 0.4 |
| F9 | Dowel pin 2 x 6 mm steel | ISO 8734 | 8 | IF-19 spinner anti-rotation | 0.15 | 1.2 |
| F10 | Brass standoff M3 x 6 F/F | | 8 | IF-13 | 0.6 | 4.8 |
| F11 | Silicone grommet 8 x 3 mm 50A (FC anti-vibe) | generic FC damper | 8 | IF-13 | 0.3 | 2.4 |
| F12 | Gold bullet 8 mm M/F pair | Amass AS150 pin set | 4 pairs | IF-04 | 6 | 24 |
| F13 | Gold bullet 3.5 mm pair | Amass | 12 pairs | IF-12 phase leads | 1.2 | 14.4 |
| F14 | XT30 pair | Amass XT30U | 2 | FC power, arming | 2.5 | 5 |
| F15 | JST-GH 6 pair + crimped leads | JST GHR-06V | 1 | IF-13 signals | 1 | 1 |
| F16 | TPU harness clips (printed) | own | 10 | bore | 0.3 | 3 |
| F17 | PU foam pad 95 x 40 x 5 mm | 40 kg/m3 | 1 | IF-03 forward stop | 1 | 1 |
| F18 | 3M DP420 epoxy 37 ml + mixing nozzles | 3M | 2 | IF-02/06/07/08/11 fillets | ~25 used | 25 |
| F19 | 3M Scotch-Weld 2216 B/A | 3M | 1 kit | IF-11 fairing bonds | 4 | 4 |
| F20 | 3M 8810 thermal tape 25 mm | 3M | 1 roll | IF-05 | 2 | 2 |
| F21 | Loctite 243 | Henkel | 1 | F1 | 0 | 0 |
| F22 | Kapton 25 um x 20 mm | | 1 roll | seams | 1 | 1 |
| F23 | CFRP tube 6 x 4 mm pultruded, 1 m | Rock West 23048 or DragonPlate | 1 (+1) | IF-07/08 | 16.6 per 4 | 16.6 |
| F24 | 7075-T6 plate 6 mm, waterjet hub frame | SendCutSend | 1 (+1) | IF-06 | 28 | 28 |
| F25 | 7075-T6 CNC pod node | Xometry / JLC CNC | 4 (+2) | IF-08/09/10 | 12 | 48 |
| F26 | 2024/7075 CNC spinner-nut, M5 (2 RH, 2 LH) | JLC CNC | 4 (+4) | IF-19 | 9 | 36 |
| F27 | 6061 1.0 mm ESC trays | SendCutSend | 2 | IF-05 | 14 | 28 |
| F28 | Pitot tube 3.0 x 2.0 x 70 stainless | | 1 (+2) | IF-15 | 2 | 2 |
| | **Total fastener/joining/metal hardware** | | | | | **~278 g** |

The model's current "fasteners, inserts, adhesive" item is 60 g; metal parts are separate items
(spar frame 80, nodes 36, spinners 23). This BOM gives fasteners/adhesive/connectors ~115 g
(+55 g), hub 28 (-52 g), nodes 48 (+12 g), spinners 36 (+13 g), trays 28 (+28 g): net **+56 g**
on these lines before the shell delta (+95 g, section 2.2). Section 6.3 carries this into the
performance model.

## 5. Parametric model plan (Fusion + CadQuery)

### 5.1 Division of labour

| Layer | Tool | Why |
|---|---|---|
| Layout numbers | `sq2/vehicle.geometry()` + optimizer JSON | Already the single source of truth; stays so |
| Parameter import | Python script `cad/src/sq2_params.py` -> `cad/out/sq2/params.json` -> Fusion socket `create_parameter` / `set_parameter` | One place that maps JSON keys to Fusion user parameters with units |
| Master model (feature tree, components, joints, drawings, STEP/3MF export) | **Fusion 360** via the socket add-in | Real feature tree, joints, interference, drawings; the socket makes it scriptable so a re-optimisation regenerates the model |
| Purchased parts | Fusion components from vendor STEP (ESC) or dimensioned envelopes (motor from drawing, pack box, FC, ADR from KiCad STEP export) | Insert as linked components with joint origins on their datums |
| Automated checks | **CadQuery** (`sq2_cad.py` refactored into `sq2_checks.py`) reading the Fusion STEP export | Keeps the existing 106 checks + 5 new ones (audit) in CI, independent of Fusion |
| FEA | FreeCAD 1.1 / CalculiX on STEP from Fusion; `sq2/fc_ccx_check.py` pattern | Already in place for the pod node; extend to hub, joints, fin column |
| Topology optimisation | Dropped for the node (CNC instead). Keep `topopt.py` for a future lightweight hub only | Saves ~5 g at the cost of a non-B-rep part; not worth it |

### 5.2 User parameter list (Fusion, all mm / deg / g)

Prefix `o_` = read from optimizer JSON (never hand-edited), `d_` = design choice set in this
plan (hand-edited, reviewed), `v_` = vendor dimension, `x_` = derived (Fusion expression).

| Name | Value | Unit | Source |
|---|---|---|---|
| o_L | 547.10 | mm | `geom.L` |
| o_fuse_d | 98.31 | mm | `geom.fuse_d` (+ d_pack_clearance delta if adopted) |
| o_nose_L, o_tail_L | 135.04, 126.20 | mm | `design` |
| o_bay_x0, o_bay_len | 150.04, 148.86 | mm | `geom` |
| o_pack_l, o_pack_w, o_pack_h, o_n_packs, o_pack_across | 144.86, 39, 49, 2, 2 | mm, - | `geom.pack` |
| o_esc_bay | 77.0 | mm | `geom.esc_bay` |
| o_x0 (rotor plane), o_x_prop, o_x_spar | 339.88, 327.88, 400.48 | mm | `geom` |
| o_cant | 0.0 | deg | `design.cant_deg` |
| o_hy, o_hw, o_r_pod, o_dihedral | 108.99, 117.78, 160.47, 47.22 | mm, deg | `geom` |
| o_pod_d, o_pod_L, o_duct_d | 41.2, 181.15, 6.91 | mm | `geom`, `design` |
| o_strut_chord, o_strut_tc, o_strut_span | 57.07, 0.1546, 90.72 | mm, - | `design`, `geom` |
| o_spar_od, o_spar_id | 6.0, 4.0 | mm | `SPARS[design.spar]` |
| o_spar_start_r | 10.4 | mm | `rep.spar_start_radius_mm` |
| o_fin_span, o_fin_root | 70.52, 45.32 | mm | `design` |
| o_fin_clock | 45 | deg | current CAD convention, confirm (audit V-9) |
| o_prop_D | 165.1 (6.5 in) | mm | `info.prop` |
| o_x_cg, o_mass | 302.25, 3034 | mm, g | `info` (check only) |
| v_motor_bell_d, v_motor_body_len, v_motor_shaft_d, v_motor_pcd, v_motor_bolt | 37.2, 38.6, 5, 19, M3 | mm | T-Motor drawing (confirm body_len 38.6 from `P.MOTOR`) |
| v_esc_l, v_esc_w, v_esc_t | 73.0, 33.6, 13.0 | mm | APD STEP |
| v_adr_w, v_adr_h, v_adr_hole | 60, 38, 3.2 | mm | KiCad |
| v_fc_pattern | 30.5 | mm | FC (TBD) |
| d_wall | 1.6 | mm | shell wall (coupon-verified, section 6) |
| d_nacelle_wall, d_fairing_wall | 1.0, 1.0 | mm | |
| d_pack_clearance | 5.0 | mm | section 3.1 (currently 3.0 in `geometry()`) |
| d_split_nose, d_split_tail | 150, 470 | mm | section 3.1; constraint: d_split_tail - d_split_nose <= 320 |
| d_spigot_len, d_spigot_gap, d_ring_t | 25, 0.3, 4 | mm | IF-01/02 |
| d_rail_w, d_rail_h, d_liner_t | 2, 3, 1 | mm | IF-03 |
| d_bulkhead_t | 3 | mm | IF-03/04 |
| d_bullet_d, d_bullet_pitch | 8, 14 | mm | IF-04 |
| d_tray_t, d_tray_z | 1.0, 14 | mm | IF-05 |
| d_hub_t, d_hub_socket_depth, d_hub_bore | 6, 28, 6.05 | mm | IF-06/07 |
| d_node_flange_t, d_node_boss_len, d_node_socket_depth | 4, 22, 25 | mm | IF-08 |
| d_nacelle_split_x | = o_x_spar - o_x0 | mm | IF-10 (expression) |
| d_fairing_root_depth, d_conduit_d, d_conduit_chord_frac | 8, 7, 0.60 | mm, - | IF-11/12 |
| d_spinner_fineness, d_spinner_gap, d_spinner_wall | 1.3, 0.4, 1.0 | - , mm | IF-19 |
| d_insert_hole_m3, d_insert_boss_od | 4.0, 7.0 | mm | F7 |
| d_fillet_root | 3 | mm | 3.4 |
| d_foot_size, d_foot_protrude | 8, 5 | mm | IF-16 |
| d_window_gnss | 35 | mm | IF-14 |
| x_bore_d | = o_fuse_d - 2 d_wall | mm | derived |
| x_spinner_d | = v_motor_bell_d + 2 d_wall + 0.8 | mm | derived, = o_pod_d check |
| x_spar_len | = o_r_pod - 1 - o_spar_start_r | mm | derived |
| x_centre_len | = d_split_tail - d_split_nose | mm | derived; must be <= 320 |

### 5.3 Skeleton (master layout) sketches and reference geometry

Component `SKELETON` (no bodies, only sketches, planes, axes, points). Everything else
references SKELETON, never another component's geometry (no inter-part sketch projection).

1. `SK_body_profile` on XZ: the revolve profile (nose ogive, cylinder, tail), driven by
   o_L, o_fuse_d, o_nose_L, o_tail_L (same math as `body_profile()`; port the formula into
   sketch constraints or generate the spline points via `execute_code`).
2. `SK_stations` on XZ: vertical construction lines at every station: d_split_nose,
   o_bay_x0, bay end, ESC bay start/end, o_x0, o_x_prop, o_x_spar, hub frame faces, d_split_tail,
   fin LE/TE. Each gets a named **construction plane** (`PL_split_nose` ...).
3. `SK_rotor_X` on the plane at o_x0 (YZ): the four pod axis points at (+-o_hy, +-o_hw),
   the four strut centre-lines from the body surface to the pod axes, and the dihedral angle.
   Cant applied as a rotation of this plane about Y by o_cant (replaces `rotor_to_station()`).
4. `AX_pod_LU` ... `AX_pod_RD`: four construction axes through the pod points along x (canted).
5. `SK_strut_section`: NACA 00xx polyline (generated points, o_strut_chord, o_strut_tc) on a
   plane normal to the strut axis, with the spar centre at 30 % chord and the conduit at 60 %.
6. `SK_pack_bay` on the plane at o_bay_x0: the two pack rectangles, rail lands, bulkhead outline.
7. `SK_fin_planform`: root/tip/sweep, on the fin plane at o_fin_clock.
8. Joint origins: one per interface (IF-01 ... IF-20), placed on SKELETON points so that
   every component's joint references a skeleton origin, not a face of another part.

### 5.4 Component tree and joints

```
SQ-2 (root assembly, user parameters live here)
+-- SKELETON                         (sketches/planes/axes/joint origins only)
+-- BODY
|   +-- NOSE_SECTION                 PA6-CF (+TPU tip body, +TPU GNSS window body)
|   |   +-- AVIONICS_TRAY            PA6-CF; children: FC, ADR (KiCad STEP), GNSS, RX, CAP_BOARD
|   |   +-- PITOT
|   +-- CENTRE_SECTION               PA6-CF (one body: shell + rails + bulkhead + sockets + bosses + TPU liners)
|   |   +-- HUB_FRAME                7075 (from SendCutSend DXF export of this component)
|   |   +-- ESC_TRAY_UPPER / _LOWER  6061; children: 2x ESC (vendor STEP), bus caps
|   |   +-- PACK_L / PACK_R          envelope + bullet plate
|   |   +-- BULKHEAD_SOCKETS         4x 8 mm female bullets, current sensor
|   +-- TAIL_SECTION                 PA6-CF with 4 fins (+TPU feet bodies, VTX antenna)
+-- POD_LU / POD_RU / POD_LD / POD_RD   (one POD design, 4 instances via pattern about X; mirror for handedness)
|   +-- POD_NODE                     7075 CNC
|   +-- MOTOR_V3120                  envelope from drawing (bell, base, shaft, 4 holes)
|   +-- NACELLE_FRONT / NACELLE_REAR PA6-CF
|   +-- SPAR                         CFRP tube
|   +-- STRUT_FAIRING                PA6-CF + skin
|   +-- PROP                         APC loft (existing)
|   +-- SPINNER_NUT                  2024 CNC
+-- HARNESS (routes as sketch paths + swept 7 mm solids for clash checks only)
+-- JIGS (alignment jig, cradle, insert press)
```

Joints (Fusion `add_joint`): rigid for every bonded/bolted pair, each with its joint origin on
a SKELETON point; `revolute` for PROP+SPINNER on the motor shaft axis (lets a `check_interference`
sweep run at 0/45/90 deg blade clocking); `slider` for PACK_L/R along x (0 to -150 mm) and for
the ESC trays and avionics tray, so the egress path is checked by driving the joint, not by
hoping. `create_rigid_group` per pod. Pods are a circular pattern of one POD component with the
mirror handled by two mirrored instances (LU/RD vs RU/LD) so a design change propagates to all four.

### 5.5 Feature plan per printed/machined part (what the feature tree contains)

| Part | Base feature | Then (in order) | Export |
|---|---|---|---|
| CENTRE_SECTION | Revolve of SK_body_profile trimmed to [d_split_nose, d_split_tail]; shell d_wall inward | Female spigot bore x2 (cut); ring frames at both ends (revolve); pack lands + rails (extrude from SK_pack_bay); pack bulkhead (extrude, 3 mm, with 4 bullet holes and harness cutouts); ESC tray rails (extrude); hub seat (cut ring 6.2 wide); 4 strut sockets (cut with SK_strut_section swept 8 mm along each strut axis + 0.3 offset); 4 harness holes (hole); insert bosses (extrude + hole 4.0); 4 hub screw dimples; TPU liner strips (separate bodies, same component, for the 3MF multi-material export); fillets | 3MF (multi-body, colour per material) + STEP |
| NOSE_SECTION | Revolve [0, d_split_nose]; shell | Male spigot (extrude ring OD = x_bore_d - 0.3, 25 mm); ring frame; key; 3 insert bosses; tray rails; pitot boss; static manifold ring; GNSS window cut + TPU window body; TPU tip body (split at x 50); antenna channels; ballast cavity | 3MF + STEP |
| TAIL_SECTION | Revolve [d_split_tail, o_L]; shell | Male spigot; ring; 4 insert bosses; 4 fins (loft SK_fin_planform root/tip, pattern 4 about X at o_fin_clock); antenna channel in one fin; TPU feet bodies | 3MF + STEP |
| HUB_FRAME | Sketch on PL_hub (ring + X), extrude d_hub_t | 4 socket holes (hole, d_hub_bore, along the strut axes, depth 28); 2 tapped M3 (create_thread); 4 M3 tapped radial; harness cutouts | DXF (waterjet) + STEP; drawing with the 4 bores called out as post-op ream |
| POD_NODE | Revolve flange + boss about AX_pod | 4x M3 clearance PCD 19 (hole pattern); centre bore 12; socket 6.05 x 25 along the strut axis; 2 nacelle shoulders; lead slot; 2x M2 tapped x2 (create_thread) | STEP + drawing (CNC) |
| NACELLE_FRONT/REAR | Revolve of the nacelle profile about AX_pod, split at d_nacelle_split_x; shell d_nacelle_wall | Strut cutout (SK_strut_section + 2 mm); inlet lip; exit holes; 2x M2 csk holes; shoulder bores | STEP + 3MF |
| STRUT_FAIRING | Sweep SK_strut_section along the strut axis, root -8 mm to tip +8 mm; shell 1.0 | Spar sleeve (revolve), conduit (cut), root/tip bond lands | 3MF (printed span-vertical) |
| SPINNER_NUT | Revolve ogive about AX_pod | M5 internal thread (create_thread, RH or LH per instance), 2 pin holes, 2 blade slots (cut by PROP swept +-0.5 mm), 2 wrench flats | STEP + drawing |
| AVIONICS_TRAY, ESC_TRAY | Sketch + extrude | Hole patterns (FC 30.5, ADR corners, standoffs), rail tabs | STEP / DXF |

Fusion features to use for the "proper" things the owner asked about: `shell` (every printed
skin), `create_hole` with insert/tap/clearance types, `create_thread` (M5 spinner, M3/M2 taps
in aluminium), `fillet` (root fillets, boss fillets), `check_interference` on the full assembly
and with the slider joints driven, `add_joint` for every interface, `create_rigid_group` per pod.

### 5.6 Optimizer -> CAD link and automated checks

```
sq2/optimize.py  -->  sq2/out/opt_<scenario>.json
                          |
                cad/src/sq2_params.py  (maps JSON -> params.json with units + the d_/v_ table)
                          |
            Fusion socket: set_parameter x N, then execute_code("rebuild + export")
                          |
        cad/out/sq2/fusion/*.step, *.3mf, drawings/*.pdf, mass_report.json (Fusion physical props)
                          |
          cad/src/sq2_checks.py (CadQuery, reads STEP)  -->  cad/out/sq2/checks.json
                          |
          sq2/vehicle.py mass model <-- mass_report.json (closes the loop, section 6.3)
```

Checks to keep (from `sq2_cad.py`): bed fit per printed part (now 300 x 320 x 325 and the
centre section length <= 320), min wall, prop tip clearances, spar-spar non-collision, pack in
bore, pod node vs motor, strut joins both ends, spinner encloses bell, DFM splits.

Checks to add (audit V-1..V-8 + this plan):
1. Egress: drive PACK slider joints -150 mm and the tray sliders: zero interference along the path.
2. Harness continuity: swept 7 mm solid from each motor to its ESC bullet has zero interference
   with structure (the conduit, node slot, socket floor hole and bore are all clear).
3. Purchased-part containment with **watertight envelopes** (replace the vendor ESC mesh in checks).
4. Strut vs motor clearance >= 1 mm; spar fully inside hub + node sockets (engagement >= 25 / 28 mm).
5. Insert boss wall >= 1.5 mm around every 4.0 hole; thread engagement >= 1.0 d on every screw.
6. Hub ring OD <= bore at the hub station and the taper start (o_L - o_tail_L) >= hub aft face (assembly from the aft end); ring OD >= bore - 0.4.
7. Antenna windows: no CF body within 10 mm of a GNSS/RX/VTX antenna volume except the TPU window.
8. Mass/CG from Fusion within +-5 % / +-5 mm of the performance model; fail the build otherwise.
9. OML continuity: max radial step across each joint <= 0.1 mm (sample the exported surface).
10. Multi-material: every TPU body shares >= 1 face with its PA6-CF host (co-print adhesion).

Run `sq2_checks.py` in CI on every JSON or parameter change; the current 106 checks were
written against CadQuery solids and will port with small edits because the exported STEP has
the same part names.

## 6. Verification plan and performance-model changes

### 6.1 Structural analysis (FreeCAD 1.1 / CalculiX, plus hand checks)

Allowables (all to be replaced by coupon values, 6.2): PA6-CF printed, XY (in-layer) tensile
60 MPa, Z (across layers) 30 MPa, E 5 / 3.5 GPa, knockdown 0.6 on layer-direction as in
`STRUCTURES.md` [ASSUME A4]; TPU 95A E 30 MPa; CFRP pultruded tube per A10; 7075-T6 Fty 430
MPa; DP420 lap shear 25 MPa (Al) / 8 MPa (PA6-CF surface) [ASSUME A16]; heat-set M3 insert
pull-out 300 N [A7].

| ID | Model | Load case | Pass criterion | Tool |
|---|---|---|---|---|
| FE-1 | Hub frame + 4 spar stubs (28 mm), ring bonded to a 60 mm length of shell | L1 thrust 4 x 31.5 N at spar tips + L3 moment 0.68 N m per spar | 7075 sigma_vm <= 430 / 1.5; bond shear <= 8 / 1.5 MPa; ring-to-shell peel < 1 MPa | CalculiX, `fc_ccx_check.py` pattern |
| FE-2 | Centre section shell with pack lands, rails, bulkhead (packs as 2 x 481 g rigid masses on the rails) | L5 20 g aft (189 N onto bulkhead) + L3 4 g lateral (38 N on rails) | sigma <= 30 / 1.5 MPa (Z direction governs at the bulkhead-to-shell corner), deflection < 1 mm | CalculiX shell + solid |
| FE-3 | Nose joint J1 (spigot, ring, 3 screws/inserts) | 180 N side + 24 N axial + 55 N suction on the forward shell | insert pull-out <= 300 / 1.5; spigot bearing < 30 / 1.5 MPa; OML step under load < 0.2 mm | CalculiX; coupon C-3 |
| FE-4 | Tail section: 4 fins as columns with TPU feet, J2 spigot | L5 610 N (4 feet, 1.2 asymmetry factor -> 183 N on one) | Euler buckling of fin (NACA 0008, 45 mm root, 70 mm span, PA6-CF 2 walls + gyroid): P_cr = pi^2 E I / (0.7 L)^2 with I ~ 2.6e3 mm4 (hollow) -> ~5.3 kN [calc], so MS large; check the fin root fillet stress instead <= 30 / 1.5 | hand + CalculiX |
| FE-5 | Pod node (CNC 7075) + motor bolts | L1 + L4 + spar moment | sigma <= 430 / 1.5; bolt group per IF-09 | CalculiX, replaces `topopt.py` for the node |
| FE-6 | Strut fairing + skin modal | free-free and pod-on-spar bending with the 250 g pod mass | f_n of pod-on-spar >= 1.5 x expected 69 Hz (`STRUCTURES.md` item 4) and no mode within +-15 % of 1P (450 Hz) or 2P | CalculiX modal; flutter check stays `sq2/flutter.py` |
| FE-7 | Spinner-nut at 1.2 x 31 krpm = 37.2 krpm | centrifugal + prop clamp preload | sigma <= 0.9 Fty (2024: 325 MPa) | hand (hoop) + CalculiX if wall < 1 mm |
| FE-8 | Avionics tray on grommets | base excitation 1P 450 Hz, 2 g | transmissibility < 0.2 at 450 Hz (f_n 60-80 Hz, zeta 0.1) | hand; measure with the FC IMU on the bench |

### 6.2 Coupons (print and test before freezing any allowable)

| ID | Coupon | Test | Feeds |
|---|---|---|---|
| C-1 | PA6-CF tensile, 5x XY, 5x Z (ASTM D638 type V scaled, printed on the H2D with the production profile) | tensile to failure | A4 allowables, FE-1..4 |
| C-2 | 1.6 mm shell ring, 98 mm OD, 40 mm long, standing print | diametral crush + wall thickness map (calliper, 8 places) | d_wall, shrink compensation, roundness (+-0.2 mm target) |
| C-3 | Joint J1 sample: 2 x 40 mm long ring halves with spigot + 3 inserts + screws | axial pull to 500 N, side load to 300 N, insert pull-out to failure | A7, FE-3 |
| C-4 | Spar-in-socket: 6 x 4 CFRP tube bonded 28 mm into a 7075 block (DP420) and 25 mm into a PA6-CF block | pull-out and 4-point bending to failure | IF-07/08 bond, A16 |
| C-5 | Pack bulkhead + 2 bullets + pack dummy (481 g) | 20 g equivalent = 189 N static on the bulkhead; 50 mate/de-mate cycles, contact resistance before/after | IF-03/04 |
| C-6 | Surface finish coupon, 100 x 100 mm curved (R 49), production print + filler + sand + clear | profilometer Ra/ks, mass per area of the finish system | R11, finish mass item |
| C-7 | TPU/PA6-CF co-print bond: 25 mm square overlap | peel to failure | IF-14/16 windows and feet, check 10 in 5.6 |
| C-8 | GNSS through the TPU window vs open air | C/N0 delta (dB) on the actual receiver | A12 |

### 6.3 Proof and functional tests (hardware, gate flight)

1. **Static proof**: full centre section + 4 pods on spars (no nacelles), body clamped at the
   pack bay; 1.5 x L1 (47 N per pod) applied at each motor face with a spring scale, hold 60 s,
   measure pod tip deflection (target < 2 mm), zero permanent set, no bond crack by tap test.
2. **Landing drop**: complete airframe with pack dummies, tail-down drop onto concrete from
   0.5 m (v = 3.1 m/s; with 10 mm TPU foot crush this is ~50 g peak, over-tests L5 by 2.5x;
   if the feet bottom out, use 0.2 m first). Inspect fins, J2, bulkhead, packs seated.
3. **Spin test**: every prop + spinner-nut to 37.2 krpm behind a shield (`VERIFICATION.md`).
4. **Pack swap timing** and **egress check** on the real parts (< 5 min, no tool other than one
   2 mm hex driver).
5. **RF**: GNSS fix time and C/N0, RX RSSI at 300 m, VTX range, all with packs installed and
   motors spinning at 50 % on the bench.
6. **Thermal**: ESC temperature after a 25 s full-current bench run on the trays (telemetry),
   compare with the model's 55 K.

### 6.4 Changes required in the performance model (`sq2/vehicle.py`)

Mass items (replace the current lines, all at the stations given):

| Item | Current (g) | New (g) | Station x (mm) | Note |
|---|---|---|---|---|
| fuselage shell + bulkheads | 270 | 365 | 300 | shell 270 + frames/rails/bulkhead/bosses 65 + joints/inserts 30 |
| spar cross fitting (7075) | 80 | 28 | 400 | waterjet plate, reconcile BOM 22 |
| 4x pod node | 36 | 48 | 400 | CNC 7075, 12 g each |
| 4x spinners | 23 | 36 | 313 | CNC 2024 spinner-nuts |
| fasteners, inserts, adhesive | 60 | 115 | 300 | section 4.3 incl. connectors |
| ESC trays (new) | 0 | 28 | 338 | 2x 6061 |
| 4x fins | 19.5 (TPU) | 45 | 513 | PA6-CF hollow + TPU feet (re-estimate from CAD volume) |
| finish system (new) | 0 | 35 | 300 | primer + clear at ~70 g/m2 on 0.5 m2 wetted [ASSUME A17, from C-6] |
| avionics tray + grommets + standoffs (new) | 0 | 15 | 100 | |
| **Net** | | **+312 g** | | 3034 -> ~3350 g before re-optimisation; CG moves ~+3 mm aft |

Mass growth allowance: with every item now from a CAD rollup, drop the 8 % conceptual allowance
to 3 % (AIAA S-120A, detailed design stage) once `mass_report.json` feeds the model (check 8 in 5.6):
net effect ~ +312 - 150 = **+160 g** (+5 %). Speed sensitivity: at constant power the mass
enters through trim lift and induced drag only (lift/drag ~ 28/52 N `[opt trim]`), so the
expected penalty is ~ -2 to -4 km/h [ASSUME A18; run `sq2/sensitivity.py` for the real number].
Re-run the optimizer after the mass table changes; expect it to shift `bat_shift` and `fin_span`.

Drag items to add (all into the `rows` dict, k_misc stays until CFD replaces it):

| Item | CdA estimate (cm2) | Basis |
|---|---|---|
| 2 circumferential joints (filled + Kapton) | 0.1-0.2 total | Hoerner gap/step: 0.3 mm step over 0.3 m perimeter x 2 |
| 7 countersunk screw heads (waxed) | ~0.05 | negligible if flush |
| GNSS TPU window (flush) | 0.05 | surface roughness delta only |
| Pitot tube 3 mm x 40 mm protruding | 0.05-0.1 | cylinder Cd 1.0 x 1.2 cm2 x 0.5 (in the nose stagnation region) |
| 4 strut root fillets (3 mm) | **-0.5 to -1.0** | `ARCH_STUDY` lever 4 |
| Nacelle seam at the strut station (under the fillet) | 0.05 | |
| Spinner-nut running gap 0.4 mm (was inlet slot, already modelled as `duct_d`) | 0 | same inlet |
| Net | **~ -0.3 to -0.7 cm2** | fillets outweigh the joints |

Also: `geometry()` gets `pack_clearance` as a parameter (default 3.0, plan value 5.0) and the
fin material switches to PA6-CF in the mass model; `esc_layout()` must produce the two-tray
arrangement (2 flat per tray at z = +-14) and its result must be the one the CAD uses.

## 7. Phased work plan

Ordered; each task names its deliverable and acceptance criterion. Durations assume one
engineer plus the Fusion socket; P0-P2 can overlap with the CFD work already running.
Max 2 workers in parallel per swarm rules; nodes marked (par) can run alongside the previous one.

### P0: Decisions and inputs (1-2 days)

| # | Task | Deliverable | Acceptance |
|---|---|---|---|
| 0.1 | Owner sign-off on Option B (3 sections, nose-off pack access, no belly hatch, CNC node, spinner-nut) and on `pack_clearance` 5 mm | Decision recorded in `docs/DESIGN.md` section 2 | Owner reply in the thread; open items listed |
| 0.2 | Confirm vendor facts: V3120 shaft thread + length, body_len 38.6, PCD 19 hole thread depth; APD 200F3 connector positions; Tattu custom pack with bullet plate option; H2D dual-nozzle usable X | `docs/BOM.md` rows updated with sources | Every `v_` parameter in 5.2 has a source link or a drawing |
| 0.3 | Pick the FC, GNSS, RX, VTX, current sensor (sizes, hole patterns, masses) | BOM rows 8 filled | Envelopes available for IF-13 |
| 0.4 (par) | Add `pack_clearance`, PA6-CF fin mass, mass items of 6.4, drag items of 6.4 to `sq2/vehicle.py`; re-run `optimize flown` | `sq2/out/opt_flown.json` v3 | Optimizer converges; checks in `VERIFICATION.md` re-run; speed delta reported |

### P1: Parametric skeleton and parameter plumbing (3-4 days)

| # | Task | Deliverable | Acceptance |
|---|---|---|---|
| 1.1 | `cad/src/sq2_params.py`: JSON -> `params.json` (o_/v_/d_ tables of 5.2) with units | script + output | Round-trip test: every `o_` value equals the JSON to 0.01 mm |
| 1.2 | Fusion: create the SQ-2 design, push all parameters via the socket (`create_parameter`), build SKELETON (5.3) with `execute_code` | `cad/fusion/sq2.f3d` (or cloud link) + `cad/src/fusion_build.py` | `get_parameters` returns the full table; a `set_parameter o_x0` moves every pod axis; skeleton has 0 bodies |
| 1.3 | Vendor/purchased components: motor envelope with PCD 19, ESC from STEP, pack box with bullet plate, ADR from KiCad STEP, FC/GNSS/RX envelopes | components with joint origins on datums | `check_interference` on the empty assembly = 0 |

### P2: Body sections and internals (5-6 days)

| # | Task | Deliverable | Acceptance |
|---|---|---|---|
| 2.1 | CENTRE_SECTION feature tree per 5.5 incl. rails, bulkhead, tray rails, hub seat, strut sockets, harness holes, insert bosses, TPU liners | component + 3MF/STEP export | Length <= 320; shell 1.6 everywhere (min-wall check); bed-fit check passes; `check_interference` with packs/ESCs/hub = 0 |
| 2.2 | HUB_FRAME, ESC trays, pack bulkhead sockets as components with joints | components + DXF | FE-1 input ready; ring passes the aft opening (check 6) |
| 2.3 | NOSE_SECTION with spigot, ring, inserts, tray, pitot, GNSS window, TPU tip; TAIL_SECTION with spigot, fins, feet, antenna channel | components + 3MF/STEP | J1/J2 spigot gap 0.3 +-0.05; OML step check 9 passes; slider joints for packs/trays/avionics drive the full egress with 0 interference (check 1) |
| 2.4 (par) | Coupons C-1, C-2, C-7 printed and tested (needs only the H2D and a scale/pull rig) | `docs/test/coupons_2026-xx.md` | Allowables table filled; shell roundness measured |

### P3: Pods, struts, spinners (3-4 days)

| # | Task | Deliverable | Acceptance |
|---|---|---|---|
| 3.1 | POD_NODE (CNC) with PCD 19, socket, shoulders, slot; motor joint; SPAR; STRUT_FAIRING with conduit; nacelle halves | POD component, 4 instances by pattern | Strut-motor clearance >= 1 mm (check 4); spar engagement 25/28 mm; harness sweep continuity (check 2) |
| 3.2 | SPINNER_NUT with M5 thread (RH/LH), pins, blade slots; prop revolute joint | component + CNC drawing | Blade slot clearance 0.5 mm at 0/45/90 deg; FE-7 hoop check |
| 3.3 | Fillets: strut root 3 mm, nacelle seams; drawings for hub, node, spinner, trays | drawing PDFs in `cad/out/sq2/drawings/` | Every machined part has a drawing with datums and the ream call-out |

### P4: Checks, FEA, model loop (3-4 days)

| # | Task | Deliverable | Acceptance |
|---|---|---|---|
| 4.1 | Port `sq2_cad.py` checks to `sq2_checks.py` reading the Fusion STEP; add checks 1-10 of 5.6 | `cad/out/sq2/checks.json` with >= 116 checks | All pass; CI job runs on JSON change |
| 4.2 | FE-1, FE-2, FE-3, FE-5 in CalculiX | `sq2/out/fe_*.json`, images in `docs/img/sq2/fe/` | MS >= 0 at FS 1.5 on every case; results in `docs/STRUCTURES.md` |
| 4.3 | `mass_report.json` from Fusion physical properties -> `vehicle.py` mass items; CG compare | updated `docs/BOM.md`, `VERIFICATION.md` R5/R8/R9 rows | Check 8 passes (+-5 %, +-5 mm) |
| 4.4 | Renders (iso/side/top/front, internal cutaway, exploded) + updated `docs/DESIGN.md` section 2 and 5 | `docs/img/sq2/v3/*.png` | Owner review: every interface in 3.2 visible in at least one render |

### P5: Build readiness (hardware, 2-3 weeks calendar, mostly waiting)

| # | Task | Deliverable | Acceptance |
|---|---|---|---|
| 5.1 | Order: CFRP tube, 7075 plate (waterjet), CNC nodes + spinners, inserts, bullets, adhesives, 2x custom packs with bullet plates | POs + tracking in `docs/BOM.md` | All parts have ETA |
| 5.2 | Print centre section first (longest, riskiest), then nose, tail, struts, nacelles; coupon C-6 finish | parts on the bench, photos | Centre section roundness +-0.3 mm, no warp > 0.5 mm over 320 mm |
| 5.3 | Coupons C-3, C-4, C-5, C-8 | test log | Values >= plan allowables; else revise IF-01/07/08 |
| 5.4 | Sub-assemblies SA-1..4, integration 4.2, static proof + drop + spin tests 6.3 | assembled vehicle, test log, `VERIFICATION.md` hardware rows | All gates in 6.3 pass; pack swap < 5 min |

Total: ~15-18 working days of engineering (P0-P4) before parts arrive, then build.
P(plan executes as written within 1.5x the estimate): ~65 %. Most likely slip: Fusion socket
limitations on sweeps/lofts of NACA sections and multi-body 3MF export, fallback is to build
those two features in CadQuery and import as STEP into the Fusion component (keeps the joints).

## 8. Decision summary

| # | Decision | Choice | Alternative kept open |
|---|---|---|---|
| D1 | Structural architecture | B: 3 printed PA6-CF sections, designed spigot joints, monolithic centre section | SLS bureau one-piece body if a large-format option appears |
| D2 | Pack access | Remove nose (3 screws), packs slide out forward, blind-mate bullets | Dorsal ESC hatch spec in 3.3 if wanted |
| D3 | Primary load path | CFRP 6x4 spars -> waterjet 7075 hub ring bonded + screwed into the centre section | none |
| D4 | Pod node | CNC 7075, B-rep, 12 g | topology-optimised AM only if mass becomes critical (saves ~5 g/node) |
| D5 | Spinner | CNC spinner-nut on the M5 shaft, RH/LH per rotation, 2 pins | printed spinner + separate nut (lighter, less secure) |
| D6 | Fins | PA6-CF integral with the tail section, TPU feet | none (TPU fins fail at q 20 kPa) |
| D7 | ESCs | 2 flat 6061 trays on rails, thermal tape, screwed to the hub bosses | |
| D8 | Avionics | Tray in the nose on grommets; GNSS under a TPU window; RX in the TPU tip; VTX in a foot | |
| D9 | Model | Fusion feature tree via socket, CadQuery for CI checks, CalculiX for FEA | |
| D10 | Body OD | +2 mm via `pack_clearance` 5 mm | keep 3 mm if the optimizer penalty is > 2 km/h and rails can be 2 mm |

## 9. Assumption register

| ID | Assumption | Impact if wrong | Closure |
|---|---|---|---|
| A1 | H2D dual-nozzle usable X = 300 mm | Centre section y-extent 259 still fits; no impact unless < 260 | Measure on the machine (P0.2) |
| A2 | SLS bureau cost USD 400-900, 5-10 days | Fallback cost only | Quote if needed |
| A3 | Open-frame large-format printers warp PA6-CF | Fallback viability | n/a |
| A4 | PA6-CF printed allowables 60/30 MPa, E 5/3.5 GPa | Shell/joint margins | C-1 |
| A5 | Print times 35-40 h total | Schedule | Slicer estimate at P2 |
| A6 | +2 mm OD costs ~1 km/h | D10 | P0.4 optimizer run |
| A7 | M3 heat-set pull-out >= 300 N in PA6-CF | J1 fastening | C-3 |
| A8 | 8 mm bullets carry 280 A for 30 s | Pack blind-mate | C-5 + datasheet |
| A9 | Hub frame 28 g (model 80 g, BOM 22 g) | Mass/CG | CAD rollup P4.3 |
| A10 | Pultruded CFRP 6x4 tube: 1.2 GPa, E 120 GPa | Spar MS (currently 9) | Vendor datasheet + C-4 |
| A11 | Grommet stack f_n 60-80 Hz isolates 450 Hz 1P | FC/ADR noise | FE-8 bench |
| A12 | TPU 95A 1.6 mm window < 0.5 dB at L1 | GNSS fix | C-8 |
| A13 | 10 AWG at 280 A for 25 s: dT ~ 25 K | Bus wiring gauge | hand calc check + bench thermal |
| A14 | Each OML seam 0.1-0.2 cm2 | Drag budget | CFD or Hoerner refinement |
| A15 | CNC spinner-nut 9 g hollow | Mass; prop balance | CAD volume P3.2 |
| A16 | DP420 on PA6-CF 8 MPa | Hub ring bond, spar sockets | C-4 |
| A17 | Finish system 70 g/m2 | Mass | C-6 |
| A18 | +160 g costs 2-4 km/h | R1 margin | `sq2/sensitivity.py` |
| A19 | Motor body_len 38.6 mm and node offset 22 mm give x_spar - x0 = 60.6 mm | Spar station, pod node | Vendor drawing, P0.2 |
| A20 | Tip-over half-angle 16 deg is acceptable for a tail-sitter in < 15 km/h wind | Launch/landing ops | Field test; widen feet (fin span) if not |

## 10. Revisions found while building the v3 CAD (2026-10-16)

Building `cad/src/sq2_v3.py` against this plan surfaced four conflicts. Each was found by a
check or a number, not by preference; `cad/out/sq2/v3/checks.json` holds the evidence.

| ID | Plan said | Problem (measured) | v3 does | Affects |
|---|---|---|---|---|
| R1 | J2 tail joint at x 470, hub ring bonded into the centre section | The 97 mm hub cannot be inserted from the front (pack shelves + bulkhead at x 299 block it) nor from the rear (boat-tail bore at x 470 is 72 mm). A bonded hub is also never removable, so the ESCs behind the bulkhead could not be serviced. | **J2 is the hub plane.** The 7075 hub (6 mm, OML band) is clamped between the centre section (x 150-397.5) and the aft section (x 403.5-547) by 4 lips each way under the skins, 16x M3 radial into tapped lips. Aft section = 144 mm incl. fins. | IF-02, IF-06, D3, D7 |
| R2 | J1 spigot wall 1.6 mm, pack corners clear | 2 packs side by side put the outboard pack faces at |y| = 40.5 mm and the rounded corners at r 47.1 mm; spigot ID would be 47.2 mm with 3 mm pack edge radius only (0.1 mm) and the M3 bosses hit the pack corners. | Spigot 1.2 mm wall, 26 mm long, relieved by 2 x 26 mm windows at 3 and 9 o'clock; 3 radial M3 at 35/180/325 deg (above the packs, under the divider). | IF-01 |
| R3 | Harness conduit 7 mm round at 60 % chord | Strut t/c 0.155 x 57 mm chord leaves 6.7 mm total thickness at 60 % chord: a 7 mm bore breaks through both skins. | 3.4 x 10.3 mm slot at 48-66 % chord (3 x 16 AWG side by side, 2.9 mm OD), 0.8 mm walls. | IF-12 |
| R4 | 2 ESC trays at z = +/-14, slide in from the front with packs out | Trays cannot pass the pack bulkhead (it carries the bullet sockets and has to be a full disk for the 189 N landing load). | One 1.5 mm 6061 power sled at z = 0 with 2 ESCs per face (stack 41.5 mm), on rails in the centre section; serviced from AFT after splitting J2 and sliding the rotor assembly back on harness slack. | IF-05, D7 |

Also: hub mass from the CAD is 47 g (model carried 80 g, plan 28 g: closes A9); pack edge
radius 3 mm added as assumption A21 (affects pack egress, check K2).

Mass/CG closure (`cad/out/sq2/v3/fusion_mass.json`, Fusion physical properties with
vendor-mass densities on purchased parts): solids 2561 g + 433 g unmodelled line items =
**2994 g, x_cg 299.0 mm**, vs optimizer 3034 g (incl. 8 % growth) / 302.2 mm. Growth
allowance actually consumed: 184 g of 225 g. CG 3.2 mm forward of the model (inside the
+/-10 mm robust band).

## 11. v3.1 revisions: buildability pass against the 2026-10-16 CAD audit

The independent audit (`docs/audit/2026-10-16/V3_CAD_AUDIT.md`) found that the v3 model was a
layout with joint geometry sketched in, not a buildable set of parts: every check asked "do
these overlap?" and none asked "is there anything here?". v3.1 reworks the parts and adds
positive-geometry checks. Each change is driven by a measured finding, not preference, and is
guarded by a check in `cad/out/sq2/v3/checks.json`.

| ID | Audit finding | v3.1 fix | Check |
|---|---|---|---|
| R5 (C1) | 4 harness holes (12 mm at r 28.3, 45 deg) cut through all 4 spar bosses: 17-19 % annulus over r 24..33; hub splits in two | Harness holes moved to the 0/90/180/270 deg bisectors, r 30, 8 mm dia (42-48 deg off every boss) | `C1 hub boss {LU..RD} solidity >= 95 %` (now 100 % at every r) |
| R6 (C3/P1) | Pod node imported as 2 disjoint mesh bodies, open-ended 17.6 mm socket, no M2 taps, no phase slot | Node rebuilt parametrically in `build_node()`: one 7075 solid, 4 mm flange (4x M3 PCD19), thick-wall blind spar socket (open inboard, blind outboard, 1 mm floor), 2x M2 set-screws, 2 mm nacelle seat ring, 10x4 phase slot; ~27 g | single-solid; socket encloses spar >= 20 mm; 6x M2 + 4x M3 hole inventory |
| R7 (M2/P3) | Spinner 2 bodies, no M5 thread, no drive feature | Spinner one solid with an M5 boss (8 mm thread bore), 2 wrench flats, 2 pin-spanner holes; PA6-CF body + heat-set M5 insert (7075 nut is the heavier production option) | spinner single-solid; M5 thread present |
| R8 (M2/P2) | Nacelles unfastened, front nacelle 3.3 mm short of the node | 4x M2 (2 front, 2 rear) through the nacelle walls into the node seat ring | 2x M2 per nacelle hole inventory |
| R9 (C2) | J2 bearing on a 1.6 mm skin with csk M3: 27-80 N vs 228 N at 20 g | **Decision: radial M3 into the 3 mm 7075 lip + an external 0.8 mm 7075 washer plate** (not an axial flange). The thin-ring hub has no bolt-PCD material, and an axial flange needs a bore-spanning disc that would block the 76 mm sled egress (R4). The washer plate spreads the head/shank load; the 1.6 mm skin is clamped between the plate and the 3 mm lip, not the bearing member. | 4+4 M3 hole inventory; 8 washer plates |
| R10 (M1/M7) | J1 inserts in 3.8 mm of plastic (1.9 mm in air); 0.54 mm forward pack play; 0.15/0.1 mm fits vs +-0.2 print | J1 insert bosses 7 mm deep projecting inward (insert fully embedded); packs shifted aft 3 mm for a real PU foam crash pad; J1 gap 0.15->0.30, J2 lip gap 0.1->0.25, 15 deg lead-in chamfers | boss depth >= insert len; foam >= 2 mm; gap params; spinner-nacelle min-distance |
| R11 (M3/M6) | Sled had no screw/hole and was unreachable; packs insert swapped | Sled retained at the bulkhead (2x M3 from the pack bay, packs out); 3 mm asymmetric divider key rib | sled 2x M3; keying rib |
| R12 (C4/M4) | Aft unprintable: fins 2.0-2.7 mm NACA0008, sub-0.8 mm LE/TE; 88 mm bulkhead bridge; feet on fin tips buckle | Fins t/c 0.08->0.12; pack bulkhead is a SEPARATE flat-printed PA6-CF disc bonded onto a 2 mm ledge (no 88 mm bridge); landing feet are TPU skids on the BODY at x 520 (0/90/180/270 deg), not the fin tips | no bridging slab (fill < 4x annulus); bulkhead a separate part; fin t/c >= 0.12; feet at x_skid |

### Section 10 (R5+): service boundary (audit C5)

The audit (C5) showed the plan's "rotor assembly off aft" sequence is impossible once bonded:
the four strut-fairing roots are bonded into BOTH the centre and aft half-sockets straddling
the J2 (hub) plane, so pulling the rotor assembly aft would pull four bonded roots out of the
centre half. The v3.1 service boundary is therefore stated explicitly:

- **Factory (pre-bond) build order, one-way:** (1) lay up the four CFRP spars into the hub
  bosses and node sockets (DP420, 2x M2 set-screws per node); (2) bond the strut fairing roots
  into the aft section half-sockets ONLY; (3) install the power sled on its rails from the aft
  end and screw it to the bulkhead (2x M3); (4) run the harness through the hub bisector holes
  and the node phase slots; (5) clamp the hub between the centre and aft sections with the 16x
  M3 J2 screws (radial, into the 3 mm lips, under the 0.8 mm washer plates); (6) the centre
  half of each fairing socket is a DRY fit sealed with removable filler (Kapton + peelable
  sealant), NOT DP420 - this is what lets the aft section + hub + pods come off as one unit.
- **Field-serviceable without debonding:** packs (nose off, through the J1 spigot); avionics
  tray (nose off); props and spinners (spinner-nut off); the four J2 screw rings.
- **Field-serviceable by splitting J2 (remove 16x M3, peel the centre-half fairing seals):**
  the power sled and ESCs slide out aft on harness slack; a motor/node/pod is removed with its
  spar still bonded.
- **Shop-only (requires debonding a spar or a fairing root):** replacing a spar, a hub, or a
  single strut fairing. These are glued joints by design; budget a new node/spar set.

This boundary is a deliberate trade: the dry-fit centre fairing seams cost a field seal step
but keep the rotor assembly removable. If a fully-bonded airframe is preferred (lighter, no
seams), the sled and ESCs become shop-only and the plan must say so.


### Section 11a: spar-root margin follow-up (coordinator check, 2026-10-16)

Independent hand check of the v3.1 governing case (20 g pod-down): pod mass 248 g x 20 g =
48.7 N at arm r_pod - R = 111.3 mm -> M = 5.42 N m; 6x4 CFRP tube sigma = 318 MPa;
MS = 700 / (1.5 x 318) - 1 = **+0.47** (agrees with margins.py +0.48). The margin rests on
an assumed 700 MPa flexural strength (commodity pultruded tube datasheets range 500-800 MPa;
at 600 MPa the MS is +0.26). Options, all inside the strut's 8.8 mm max thickness
(0.8 mm fairing wall each side leaves ~7.2 mm):

| spar | MS (FS 1.5, 700 MPa) | mass per 200 mm |
|---|---|---|
| 6x4 pultruded (current) | +0.47 | 4.9 g |
| 7x5 pultruded | **+1.15** | 5.8 g |
| 6.5x4 roll-wrapped | +0.99 | ~6.5 g |

Recommendation: adopt 7x5 (+3.6 g for four spars) once the vehicle model's SPARS menu gets a
7x5 entry and the strut 'spar fits strut' constraint (margin 0.026 at 6 mm) is re-checked with
a 7 mm tube (needs strut t/c >= 0.17 at the root or a local root bulge). Coupon-test the
purchased tube's flexural strength before flight either way.
