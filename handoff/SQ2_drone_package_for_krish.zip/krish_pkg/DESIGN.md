# SQ-2 Design Description

Living document. Numbers come from generated files; when they disagree, the files win:
`sq2/out/opt_<scenario>.json` (vehicle), `cad/out/sq2/checks.json` (assembly),
`sq2/out/pod_node_report_*.json` (pod node), `docs/BOM.md` (parts).

## 1. Goal and how it is judged
Beat 657.59 km/h, Guinness "fastest ground speed by a battery-powered RC quadcopter", average
of runs in opposite directions. Requirements R1-R11 and their checks: `docs/PROGRAM.md`.

## 2. Architecture (and why)

| Decision | Choice | Reason / evidence |
|---|---|---|
| Layout | Body of revolution, 4 puller pods on an X, rotor plane pitched by a small cant (0-5 deg, optimizer variable) | Both record vehicles use puller pods on a slender body. SQ-1's 28 deg cant stalled the struts (`sq2/sq1_audit.py`). |
| Props | APC 7x15E clipped to 5.75-6.5 in | Same family both record vehicles flew; BEM model built from APC's own geometry file and calibrated on APC data (`sq2/bem.py`). |
| Prop rpm | <= 36,000 with spin test to 43,200 | APC's published E-prop limit (150000/D) caps speed at ~540 km/h (`opt_vendor.json`). Record vehicles ran 30-40k. Spin test is a hard gate before flight. |
| Power | 14S1P, two custom 7S packs of R-Line V5 cells | 14S needs 4x fewer amps than 12S2P at the same power; Blackbird flew 14S. Catalogue fallback: 12S2P 4x Tattu R-Line V5 6S1400. |
| ESC | APD 200F3[X]v2 (14S, 200 A), in the fuselage | Body ESCs let the nacelle shrink to the motor bell (41.2 mm OD), removing ~8 cm2 of pod drag vs ESC-in-pod. Phase leads run inside the struts. Vendor STEP used. |
| Motor | T-Motor V3120 (700 KV catalogue; 900 KV rewind option) | Peregreen V4 chose it for thermal reliability over the AOS 3220. |
| Spinner | Covers the full motor bell; nacelle lip OD = spinner base OD | Peregreen V4 measured +30 km/h from spinners alone. Inlet slot between spinner and lip feeds the motor duct. |
| Structure | 4 CFRP half-spars, each from a 7075 hub frame in the body to a topology-optimised AlSi10Mg pod node | Two continuous diagonal spars collide at the axis. Hub and node sockets give >= 1.5 OD bond engagement (checked in CAD). |
| Skin | PAHT-CF, 1.6 mm, filled and sanded to ks <= 10 um (R11) | Sensitivity: ks 30 um costs ~22-34 km/h. |
| Tail | 4 TPU fins on an X, also landing feet | Fins set the short-period pole (R3); size comes from the optimizer. |

## 3. Pitch stability philosophy
The vehicle is designed close to neutral static stability. The optimizer constrains the
linearised short-period pole so the time to double is >= 3 x the rotor-speed actuator time
constant (30 ms, to be bench-measured) at the nominal CG and with the CG 10 mm fore or aft.
Derivation: `sq2/pitch_dyn.py`. A design with a 13 ms time to double existed in the search
space and was rejected by this check.

## 4. Margins carried in the design point
- Excrescence/interference drag 40 % of parasite (k_misc 0.40); speeds are also reported at 0.20.
- Mass growth +8 % (AIAA S-120A, conceptual).
- CG +/-10 mm for R3.
- Energy <= 80 % of pack, motor dT <= 80 K, ESC dT <= 60 K, accel <= 25 s.
- Structural FS 1.5 on limit loads (spar bending, pod divergence; pod node MS from FE).

## 5. Interfaces (single source of truth)
- Rotor frame to station frame: one function, `rotor_to_station()` in `cad/src/sq2_cad.py`.
- Spar station: motor body length (vendor drawing) + 22 mm pod-node socket offset, set in
  `sq2/vehicle.geometry()` and used by the CAD, the mass model and the clash constraint.
- ESC packing in the body: `vehicle.esc_layout()`, shared by the model and the CAD.
- Pod node envelope: pod OD, spar OD, rpm and thrust come from the optimizer JSON via
  `sq2/topopt.configure()`.

## 6. Known gaps (open)
See `docs/PROGRAM.md` section 4 and the latest audit in `docs/audit/`. The biggest:
drag is still handbook-based (CFD calibration in progress), 900 KV availability, custom pack
IR unmeasured, prop spin test not done, harness and hatches not yet in CAD.
