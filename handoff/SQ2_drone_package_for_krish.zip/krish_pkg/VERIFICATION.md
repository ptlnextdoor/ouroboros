# SQ-2 Verification Matrix

Every requirement in `docs/PROGRAM.md`, the check that verifies it, where the check lives, and
the latest result. "Model" = analysis only, not hardware. Re-run commands in the last column.
Updated 2026-10-15.

| Req | Requirement | Method | Check (code) | Latest result | Status | Re-run |
|---|---|---|---|---|---|---|
| R1 | Two-way avg > 670 km/h | 3-DOF trim + powertrain model, anchored to flown vehicles | `sq2/vehicle.py evaluate()`; anchors `sq2/anchor.py` | 590 km/h (model, k_misc 0.40; 610 at 0.20); independent audit of earlier design 575 (545-600), P < 3 % | **FAIL** (model) | `python3 -m sq2.optimize flown` |
| R2 | Pitch-trimmable at all speeds, pod pairs within [0, T_max] | moment balance in `excess()` | `vehicle.py pitch_moment()` | trimmed at V_max | PASS (model) | as R1 |
| R3 | Short-period t2 >= 3 tau (30 ms) at CG +/-10 mm | linear 2-state model | inline in `evaluate()`; doc + cross-check `sq2/pitch_dyn.py` | optimizer-enforced | PASS (model); tau ASSUMED, bench-measure | `python3 -m sq2.pitch_dyn` |
| R4 | Every purchased part real, datasheet + vendor STEP where published | sourcing | `docs/BOM.md`, `cad/vendor/` | ESCs: vendor STEP; motor: drawing-based (no public STEP); packs: custom (quote needed) | PARTIAL | n/a |
| R5 | MS >= 0 at FS 1.5 on limit loads | spar beam + topology-opt FE + CalculiX | `vehicle.py` spar bending; `sq2/topopt.py`; `sq2/fc_ccx_check.py` | spar MS > 5; pod node min MS 23.7; hub frame NOT analysed | PARTIAL | `python3 -m sq2.topopt --opt sq2/out/opt_flown.json --vf 0.05` |
| R6 | Flutter/divergence free to 1.15 V_max | 2-DOF typical section | `sq2/flutter.py` (also optimizer constraint) | flown: none below 1.15 V_max; vendor (pre-constraint) failed at 159 m/s | PASS (model, quasi-steady) | `python3 -m sq2.flutter flown` |
| R7 | Motor dT < 80 K, ESC dT < 60 K, energy < 80 % | sortie simulation | `evaluate()` energy block; transition `sq2/transition.py` | enforced; transition 4.7 s / 7.2 Wh | PASS (model) | `python3 -m sq2.transition flown` |
| R8 | Manufacturable (bed fit, walls, materials) | CAD checks | `cad/src/sq2_cad.py` DFM checks | all printed sections fit H2D; min wall check by audit pending | PARTIAL | `cd cad/src && python3 sq2_cad.py flown` |
| R9 | Assemblable, no interference, all parts connected | CAD checks + renders | `cad/src/sq2_cad.py` (67 checks), renders `docs/img/sq2/` | 67/67 PASS; hatches, harness routes, fasteners not yet modelled | PARTIAL | as R8 |
| R10 | Avionics board ERC/DRC clean, fab-ready | KiCad ERC/DRC + render review | `electronics/gen/route_pcb.sh`, `docs/electronics/PCB_REVIEW.md` | DRC 0 err / 0 unconnected; Gerbers rendered back | PASS | `bash electronics/gen/route_pcb.sh` |
| R11 | Surface finish ks <= 10 um | profilometer on printed coupon | none yet | sensitivity: ks 30 um costs ~22-34 km/h | OPEN (hardware) | n/a |

## Hardware tests that gate flight (none done)
1. Prop + spinner spin test to 37.2k rpm (1.2 x 31k) behind a shield, every unit.
2. Motor/prop thrust stand at 25-31k rpm, compare to `sq2/bem.py` (the prop deck is BEM
   extrapolation above APC's 27k table).
3. Rotor-speed step response (actuator tau for R3).
4. Pack IR at delivery (model assumes 2.5 mOhm/cell at 1400 mAh, 1/capacity scaling).
5. Static proof load of the strut/spar/hub/node assembly to 1.5 x limit.
6. Coupon roughness (R11).

## Independent audits
- `docs/audit/AUDIT_2026-10-15.md` (first audit, 13 findings)
- `docs/audit/2026-10-15b/MODEL_AUDIT.md` (model: arithmetic verified, stale-JSON and
  prop-extrapolation findings, both actioned)
- `docs/audit/2026-10-15b/VISUAL_AUDIT.md` (CAD + PCB visual: PCB clean; CAD V-1..V-8 actioned)
