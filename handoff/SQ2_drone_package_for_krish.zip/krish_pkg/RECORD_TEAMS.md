# What the record teams actually built (research, 2026-10-16)

Sources: build videos and transcripts (downloaded and read in full), frames pulled from the
CAD segments, press coverage. Video IDs: Peregreen V4 build `L_O45iEar4M` (Luke + Mike Bell),
Blackbird build `KwRSAfoW5uo` and 730 km/h run `k9n1h0rn9No` (Ben Biggs + Aidan Kelly,
Drone Pro Hub). Frame grids: `docs/research/img/`.

## Scoreboard

| Vehicle | Result | Status |
|---|---|---|
| Peregreen V4 (Bell) | 657.59 km/h two-way (656 / 659) | Official Guinness record, 11 Dec 2025 |
| Blackbird (Biggs/Kelly) | 626.42 km/h (599 up / 655 down) | Guinness, 8 Dec 2025 (held 3 days) |
| Blackbird, custom props | 685 km/h two-way (730 down / 640 up), wind 35-60 km/h | Unofficial (no observers), 20 May 2026 |
| Apex Recordhunter (Quantum Systems) | 699 km/h level | Internal test, certification pending |

**Implication for SQ-2:** the bar that matters in practice is ~690-700 km/h, not 658.
Our robust 556 km/h and nominal 590 km/h are 15-20 % short.

## Hardware, side by side

| | Peregreen V4 | Blackbird | SQ-2 v3 (ours) |
|---|---|---|---|
| Motors | T-Motor 3120, 900 KV (picked over AOS 3220 and AMAX 2826 for low temperature and no stator scraping; AOS made 9-15 % more thrust) | AMAX 2826, custom-wound, phase leads left long and soldered straight to the ESCs | T-Motor V3120 700 KV (model) |
| ESC | APD 120F3 | APD 200F3 (35 g, 200 A, 14S), four side by side joined by a **3 mm copper rod bus**, no cooling (10 s bursts) | APD 200F3 x4 on a 6061 sled |
| Pack | LiPo (12S class) | **Custom SMC 7S x2 in series = 14S**, 1600 mAh: 8 s full throttle + 90 s cruise. Overcharged to 4.3 V/cell for the record. ~400 A for 10 s; heat-shrink melted, 80 C packs | 2x custom 7S2600 = 14S (same architecture) |
| Props | APC 7x5(E) trimmed to ~6 in | APC 7x15 cut to ~6 in (tip Mach limit: 7 in at 30k rpm + 600 km/h = M 0.95); then **hand-made CF sawtooth-LE props, more pitch than 15 in** for 730 km/h | APC 7x15E clipped to 6.5 in |
| Config | Pusher, tail-sitter, **tilting servo** (flies "like a plane") | **Puller** (props ahead of the arms, mass-balance logic vs flutter, clean air for props, motor cooling) | Puller (rotor plane ahead of the spar) |
| Spinner | 3D printed, spin-tested past 70k rpm on a bench rig | **CNC aluminium, thin wall, centre piece is the prop nut**; ducted "Meredith effect" flow over the windings | Spinner-nut concept (printed in v3 CAD; plan says CNC) |
| Body | One piece on Bambu H2D, PA6-CF + support filament (smoother underside), sanded and polished, TPU tail for landing, LEDs in a transparent tail | **CNC-cut carbon plate frame (PCBWay) + PETG printed shells glued**, hand-sanded; hatch with tape | 3 sections PA6-CF + TPU, 7075 hub, CFRP spars |
| Aero tool | AirShaper CFD (online) | Hand calcs + Fusion section views | Own model + OpenFOAM (not yet validated) |
| Camera/video | DJI air unit, front camera; filming drone carries an Insta360 X5 in a TPU tail mount | DJI digital, **VTX stripped from its case with a CNC heat sink flush with the skin**; camera in the nose tip | None yet (this doc fixes that) |
| Failure modes seen | Prop came off mid-air (shown); stator scraping on AOS | **Video loss at 600+ km/h passing the pilot** (lost one drone); battery sag to 3.65 V/cell upwind; 50 Hz frame resonance (notch filter); D-gain 0 caused oscillation over 400 km/h | not flown |

## What their CAD looks like (and why ours looked worse)

Blackbird CAD (Fusion 360, frames at 6:24-6:56, 10:00, 12:24-12:40 of `KwRSAfoW5uo`):
* Smooth single-face B-spline surfaces: the body, nacelles and spinners have **no faceting**.
  Ours were revolves of 48-point polylines, which Fusion shows as 48 conical bands with a
  seam line each (the "lines everywhere" look).
* Vendor-like purchased parts: motors with finned bells and visible stator, props with real
  blade shape, the camera module as a separate block at the nose tip (exploded view, 10:00).
* Section analysis views with hatching to show wall thickness, spinner internals and the
  motor mount (12:24-12:40). That is how a designer shows interfaces.
* One material colour per part (grey printed body, black spinners, white props).

## Decisions taken for SQ-2 from this research

1. **Camera: DJI O4 Air Unit Pro** (camera module 25.55 x 20 x 23.3 mm, 16.4 g incl.
   coax, M2 x 4 mounting; transmission module 33.5 x 33.5 x 13 mm, 32 g total, 1/1.3 in
   sensor, 4K/120, input 7.4-26.4 V so it needs a BEC from 14S). Camera in the nose tip on
   the axis looking forward through a flush window (Blackbird layout). Not a DJI Osmo:
   an Osmo Action is ~145 g and 70 x 44 x 33 mm, which would not fit the nose and costs
   ~5 km/h in mass alone. Optional second camera for footage: Insta360 X5 on the
   chase drone, as the Bells did.
2. **Pitot moves off the axis** to make room for the camera: a short stainless boom from
   the lower nose, calibrated against GPS two-way runs (Guinness measures ground speed
   anyway; the ADR airspeed is for our model validation, not the record).
3. **Video-loss mitigation** (lost a Blackbird): antennas in different orientations (one
   in the TPU tip, one in a fin foot), fly the pass with the pilot well off the line,
   and record on board (O4 Pro records 4K internally, so a link dropout loses the
   live view but not the footage).
4. **Smooth B-spline geometry everywhere** and real appearances in Fusion; detailed
   motor model built from the T-Motor drawing (no public STEP found).
5. Re-check propulsion against what actually flew: 900 KV 3120 (Bell) and AMAX 2826
   (Biggs) are both proven at 650+; our 700 KV choice came from the model, and the open
   question to T-Motor about 900 KV stands. The sawtooth CF props are the single change
   that took Blackbird from 655 to 730 downwind.
