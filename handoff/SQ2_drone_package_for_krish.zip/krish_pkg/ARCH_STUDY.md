# SQ-2 Architecture Study: closing the drag gap

Date 2026-10-15. Baseline: `sq2/out/opt_flown.json` (582-600 km/h, CdA ~32-33 cm2 at k_misc
0.40). At constant power, V ~ CdA^(-1/3); 670 km/h needs **CdA ~ 21 cm2**, i.e. -35 %.
Record vehicles back-calculate to 20-27 cm2 (`sq2/anchor.py`).

## Drag budget at the optimum (k_misc 0.40 applied on top: total 32.3 cm2)
| Component | cm2 | share |
|---|---|---|
| pods (4) | 8.7 | 27 % |
| struts (4) | 7.0 | 22 % |
| fuselage | 4.3 | 13 % |
| junctions | 1.9 | 6 % |
| fins, ducts, base | 1.8 | 5 % |
| k_misc allowance | ~8.5 | 27 % |

## Levers, ranked by expected gain per unit risk
| # | Lever | Expected dCdA | Evidence / status | Risk |
|---|---|---|---|---|
| 1 | **Validate pod drag.** Model uses Raymer fuselage FF (2.54 at fineness 3.4) x Q 1.3; Hoerner's body FF gives 1.42. If Hoerner/CFD is right, pods are over-predicted ~2x. | -2 to -4 | CFD worker running SQ-2 assembly; decide after | none (modelling) |
| 2 | **Carbon-skinned thin struts** (implemented, `skin_ply`): torsion from skin lets t/c and chord shrink. | -2 to -3 | point probe 582 -> 601 km/h; optimizer re-running | build: wet layup on printed core |
| 3 | **Validate k_misc.** 0.40 is a margin, not a measurement. Polished record bodies suggest 0.15-0.25. | up to -4 | sensitivity: 0.40 -> 0.20 = +19 km/h | none (modelling); finish spec R11 |
| 4 | **Fillet junctions** (Hoerner: fillets cut T-junction drag ~50-70 %). | -1 | add to CAD + model | low |
| 5 | **Pod-strut blending** (pod and strut as one lofted body, strut LE swept into pod). | -1 to -2 | needs CFD | medium |
| 6 | **900 KV V3120** (not drag but power: duty at ESC cap). | equiv. +30 km/h | part availability unverified (BOM.md) | supply |
| 7 | **Fewer, larger props / coaxial** | n/a | not a quadcopter under the Guinness definition (four separate rotors) | rule |

Combined plausible: levers 1-4 give -7 to -12 cm2 -> 20-25 cm2, i.e. **~630-680 km/h**,
which brackets the record. Lever 6 adds ~+30 km/h on top if the part exists.
P(record) after these levers, my estimate: 20-35 %, dominated by whether the CFD pod/k_misc
numbers come in at the optimistic end. Most likely way this is wrong: the k_misc 0.40 is
real (interference at 4 strut roots and 4 pod junctions at Mach 0.5 is large), in which
case the ceiling is ~620 km/h with V3120-class motors.

## Decisions pending CFD
- If CFD pod CdA <= 1.3 cm2/pod: switch pod FF to Hoerner, re-optimise.
- If CFD total CdA (no k_misc) is within 15 % of the buildup: set k_misc to the CFD residual
  instead of 0.40.
