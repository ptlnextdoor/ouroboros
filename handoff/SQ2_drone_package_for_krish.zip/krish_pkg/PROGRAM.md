# SQ-2 Program Plan (living document)

Owner: Aayu. Goal: beat 657.59 km/h (Guinness, battery RC quadcopter, two-way average).
Engineering bar: what a SpaceX-style hardware team would accept for a design review (PDR->CDR).
Every claim below carries its verification method. "Model says" is not "verified".

## 1. Requirements (each with owner check)

| ID | Requirement | Verification |
|---|---|---|
| R1 | Two-way avg > 670 km/h (2 % margin over record) at sea level, 15 C | 3-DOF trim model + drag uncertainty band; later flight data |
| R2 | Trimmable in pitch at every speed from transition to V_max with both pod pairs in [0, T_max] | `sq2/vehicle.py` 3-DOF trim |
| R3 | Stabilisable: pitch divergence time-to-double > 3x actuator (rpm) time constant, or statically stable | linearised short-period model (todo) |
| R4 | Every purchased part exists, is in stock, and has a vendor datasheet; vendor STEP where published | `docs/BOM.md` with links + `cad/vendor/` |
| R5 | Structure: MS >= 0 at FS 1.5 on limit loads at V_L = 1.1 V_max, incl. joints, fasteners, print layers | hand calcs + FEA (own SIMP FE + CalculiX) |
| R6 | Flutter/divergence free to 1.15 V_max | pod-on-spar bending-torsion flutter check (todo) |
| R7 | Motor dT < 80 K, ESC within rating, pack energy < 70 % for a full record sortie | sortie sim in vehicle.py |
| R8 | Manufacturable: every printed part fits bed, min wall >= 2 nozzle widths, orientation vs load documented; metal parts quotable | CAD checks + DFM script |
| R9 | Assemblable: every bolt reachable, every wire has a path, connectors accessible, no interference | CAD interference + connectivity checks |
| R10 | Avionics board: ERC 0, DRC 0, 0 unconnected, fab-ready Gerbers + BOM + CPL | KiCad + copper-mcp DRC gate |

## 2. Known blockers (from audit 2026-10-15, docs/audit/)

1. Prop rpm ceiling: APC E props at published 150000/D cannot reach R1 (7x15E thrust ends at 537 km/h).
2. Drag: honest CdA ~63 cm2 (roughness, bell step, duct, junctions). Record needs ~25-30 cm2 class.
3. Stability: long thin body with CG behind rotor plane is unstabilisable (14 ms time-to-double).
4. CAD not an assembly (struts float / pierce batteries), no spar joint, no nacelle split.

## 3. Architecture direction (to be validated, not assumed)

- Short, fat body; packs side by side around the rotor plane so CG ~ rotor plane (R2/R3).
- Spinner fully covering the motor bell; motors in pods with the ESC buried in the strut root/body
  so pods are minimum diameter (drag).
- Higher-pitch prop strategy evaluated in this order: (a) APC racing/carbon family (270000/D),
  (b) E props spin-tested to 1.25x on a shielded stand, (c) custom 3-blade or clipped props.
- Motor: re-select by power density at 30-40 krpm; V3120 700KV is current-limited, not power-limited.

## 4. Work queue (overnight)

1. Optimizer with 3-DOF trim + honest drag -> baseline; record the drag budget per component.
2. Drag reduction study: what each feature buys (spinner, buried ESC, polished skin, smaller pods).
3. Prop/motor trade with real catalogue data (APC PER3 tables, T-Motor/other motor datasheets).
4. Download real vendor CAD (STEP) for every purchased part that publishes one; record source URLs.
5. Rebuild SQ-2 CAD from params: correct strut transform, spar cross fitting, nacelle split,
   battery bay with spar gap, avionics bay with real board outline, wire paths.
6. Interference + connectivity + DFM checks as code, run on every CAD build.
7. Avionics board: DRC 0 / 0 unconnected, render-and-review each revision.
8. Periodic independent audits (contextless agent) of: model, CAD visuals, PCB visuals, BOM.

## 5. Audit log

| Date | Scope | Result | Fixed |
|---|---|---|---|
| 2026-10-15 | SQ-2 model, SQ-1 CAD, mass, packaging | 475 km/h claim invalid; 5 critical | F-1, F-2, F-3, F-6 (partial), F-11 |
| 2026-10-15b | SQ-2 performance model (`docs/audit/2026-10-15b/MODEL_AUDIT.md`) | arithmetic reproduces JSON to <0.1 %; opt JSON was stale (fixed by re-run); prop deck optimistic above 27k rpm; top speed is volts x Kv limited; central 575 km/h, band 545-600, P(record) < 3 % | stale JSON regenerated; trusted rpm cap 36k -> 31k; 16-20S option queued |

## 6. Status 2026-10-15 (overnight run 1)

Model fixes that moved the answer (all committed with explanations): rewound-motor resistance
scaled the wrong way, clipped-prop table had a 30 % step the optimizer exploited, max-thrust
solver was non-monotonic. Model now anchored to the two flown record vehicles
(`sq2/anchor.py`: Blackbird CdA ~26-33 cm2, Peregreen V4 ~20 cm2).

Current best (`sq2/out/opt_flown.json`, prop rpm <= 36k, all constraints incl. R3 with CG
+/-10 mm, 8 % mass growth): **581 km/h at k_misc 0.40, 596 km/h at 0.20**. Not a record.
14S1P 2x custom 7S3000, V3120 700KV, APC 7x15E clipped 6.5 in, ESCs in body, 3.14 kg,
CdA 36 cm2. Gap to 670 km/h is drag: the record vehicles are at 20-30 cm2.
Sensitivity (`sq2/out/sensitivity_flown.json`): misc drag, surface finish and pack IR are
each worth 15-30 km/h. CAD (`cad/src/sq2_cad.py`) builds from the optimizer JSON, 32/32
assembly checks pass; renders in `docs/img/sq2/`.

Next: CFD drag calibration (worker), then drag-reduction design work (smaller fuselage
cross-section via in-line packs, thinner struts, pod/strut integration), vendor-rpm run.

### Update 2026-10-15 ~04:00 local
- Current best (all constraints, k_misc 0.40, prop rpm <= 31k trusted range): **582 km/h**
  (603 at k_misc 0.20). Vendor-rpm: 525. Independent model audit: central 575, band
  545-600, P(record) < 3 %. Binding limit is volts x Kv (duty at ESC cap), not prop rpm.
- Catalogue scan: 16S (APD HV_Pro16S, 260 g) and AOS 3220 925KV (6S-rated) are excluded by
  mass and the motor-voltage constraint; 900 KV V3120 is the only Kv lever (~+30 km/h,
  part availability unverified).
- CAD: 4 half-spars into a 7075 hub (80 g from CAD; was 22 g assumed), topology-optimised
  pod nodes regenerated per design (9.2 g, min MS 23.7), 67/67 assembly checks.
- Honest conclusion so far: with V3120-class motors and our drag, SQ-2 is ~75 km/h short.
  Closing it needs ~-33 % CdA at constant power, or more power per pod. Next: CFD drag
  calibration (worker running), then an architecture study of smaller-frontal-area layouts.

### Update 2026-10-15 ~05:25 local
- Current best: **590 km/h** at k_misc 0.40 (610 at 0.20), all constraints incl. new R6
  flutter and ESC-fit; vendor-rpm 558. Carbon-skinned 57 mm struts on a 6 mm spar, ESCs in
  body, 14S1P 2x custom 7S2600, 3.03 kg, CdA 31.9 cm2.
- The design is constraint-tight: in the sensitivity study most single 10-60 % perturbations
  break either the short-period limit or motor dT. Margin policy needed before CDR.
- Found and fixed this round: flutter model missing damping (spurious flutter at 5 m/s), DE
  missing a known 601 design (now seeded), ESC-in-pod clash hidden by a non-watertight vendor
  mesh (visual audit V-8). CAD: pack service joint, strut harness conduits, motor bolts,
  spinner retention, 100 checks.

### Update ~06:10: robust design point
- Nominal optimum 590 km/h fails the robustness corners (pack IR +60 %, CG +/-10 mm).
- Robust optimum (`sq2/out/opt_flown_robust.json`, feasible in all corners): **556 km/h**
  (574 at k_misc 0.20), 3.33 kg, 14S1P 2x 7S3400, CdA 33.1 cm2.
- So the honest planning number with today's margins is **556-590 km/h**. The ~35 km/h cost
  of robustness is mostly pitch stability with uncertain CG/IR: measuring pack IR and
  weighing/balancing the build would recover most of it.
