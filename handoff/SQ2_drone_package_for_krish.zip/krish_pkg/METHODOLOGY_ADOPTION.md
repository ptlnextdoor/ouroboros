# Speed-drone methodology: what the record teams actually do, and how SQ-2 adopts it

Sources: Whisper transcripts in `09_transcripts/whisper/`. Luke & Mike Bell: Peregreen V2 `szxRORFl_lc` /
`wThmg8Ezm9w`, V3 `7PTsHDFMams`, V4 `L_O45iEar4M`. Ben Biggs: Blackbird build `KwRSAfoW5uo`, plus the Drone Pro Hub
record videos. Everything is paraphrased. Full per-video notes, the methods matrix and the parts list come from the
analyst worker (`09_transcripts/*_notes.md`, `METHODS_MATRIX.md`, `PARTS_LIST.csv`).

## 1. Their loop, side by side

| Phase | Bell (Peregreen V3/V4) | Biggs (Blackbird) | SQ-2 before today | SQ-2 adoption (status) |
|---|---|---|---|---|
| Target | Retake the record each round; small steps (580, then 657 km/h) | Set 600 km/h on purpose as the upper limit of what is achievable, beat the record by a margin | Model optimum 590-610 km/h | Target 700 km/h (beat Blackbird's 685 km/h average) |
| Component-first | Motor bake-off on a bench (AOS 3220, AMAX 2826, T-Motor 3120) | "Choose every component first, then design the frame around them." Prop first: APC 7x15E | Optimiser chooses KV, prop and cells | Already component-first. **Add a measured bench bake-off** (sec. 3) |
| Prop | APC 7x15E cut to about 6 in (tip Mach); custom props later | APC 7x15E cut to about 6 in; custom high-pitch sawtooth CF props took the run from 690 to 730 km/h | 7x15E clipped to 6.5 in; repitch study showed thermal limits bind | Keep 7x15E. **Custom-pitch prop study is the 700+ lever** (Biggs evidence) |
| Motor | T-Motor 3120, **900 KV** (up from 800 once drag was reduced); chosen for low temperature and no stator scraping over peak thrust | AMAX 2826 custom-wound with long leads soldered straight to the ESCs (no wire loss, thin arms) | V3120 700 KV; 900 KV rejected (546 km/h) | Our rejection of 900 KV holds *at our drag*. Bell only raised KV **after** CFD cut drag, so re-check KV after the shape optimisation (sec. 2) |
| Voltage | SMC Speedrun Drag packs, 15-16 kW peak (V3) | 14S from two custom SMC 7S packs, overcharged to 4.3 V/cell on record day; 1600 mAh sized for 8 s full throttle + 1.5 min return | 14S, 2 x 7S2600 | Same architecture. Add the **4.3 V/cell record-day option** to the model as a sensitivity case |
| ESC | TBS Lucid, **water-cooled** (CNC Al heatsinks, printed TPU gasket, clear resin water box, mini printed pump); later APD 120F3 | APD 200F3 (35 g, 200 A, 14S), four side by side on a **3 mm copper bus rod**, no cooling, 10 s bursts | APD 200F3, 44 % of BOM | Biggs's bus-bar layout fits our sled. Thermal: we budget a 60 K rise. **Water box not needed** for 10 s bursts (matches Biggs). Bus bar and bench thermal test go in the v3.3 CAD |
| CAD/CFD | Mike runs "tons" of AirShaper CFD to shape the body, minimise drag, maximise **net** thrust; V4 body ended up *larger* and smoother | (No CFD named in this video); designed by packaging and first principles | One validated full-body OpenFOAM run (CdA 32.4 cm2), hand-chosen shape | **CFD-in-the-loop Bayesian shape optimisation is running now** (`cfd/shape_opt.py`, 7 shape variables, GP + expected improvement, 25 evals) |
| Stability | "Car-window wind tunnel": model on a stick with **adjustable CG**, spinning props. Swept CG fore/aft until it flew straight on its own (**passive stability**, no tail) | Puller props ahead of the arms, reasoning by analogy with mass-balanced control surfaces (anti-flutter); clean air, better motor cooling | Fins + 20 g pod loads; pitch authority check | Add a **CFD yaw/pitch moment sweep vs CG** (same question as their car-window test). Puller config: we are already tractor (puller) |
| Thermal aero | Water cooling; transparent tail with LEDs | **Meredith-effect spinners** (CNC Al, thin walls, diffuser, then motor windings, then nozzle; the spinner nut retains the prop); **flush-mounted machined VTX heatsink**, zero drag | Ducted pods (6.9 mm duct), CNC spinner | Our spinner duct is the same idea. **Add a flush VTX/ESC skin heatsink** to the v3.3 CAD |
| Structure | V3: fully printed body; oven test of PLA, PETG and PA6-CF heat resistance (PA6-CF survives over 175 C); Prusa XL dual-material (nylon + support material); V4: Bambu H2D dual-nozzle, PETG + **TPU fused tail** for landing; twist-lock lid and tail | First prints failed; frame left unglued until tuned, because gluing stiffened it and invalidated the tune | PA6-CF printed shell, TPU feet | Same materials. **Re-tune after final bonding** goes on the checklist (Biggs crash). TPU tail fused in one print, as Bell does |
| Bench test | **Strain-gauge thrust rig** (4 gauges, amplifier, Arduino) plus a thermal camera logged through the video link; **spinner spin-to-failure** test (above 70k rpm vs 40k max) | - | None built | **Build the strain-gauge/load-cell rig and a spinner overspeed test** (sec. 3) |
| Flight ladder | Throttle steps of 70, 80 and 90 %, checking motor temperature and stator scraping after each; second body for A/B motor tests | Hover, check tune, then punch-outs; Blackbox logs found a 50 Hz frame resonance, **gyro notch filter**; never set D gain to zero (oscillation above 400 km/h) | Not started | Adopt both: step ladder, Blackbox after every flight, notch at the measured frame mode |
| Finish | Hours of **sanding and polishing PA6-CF**, sanding locking tabs flush; closed canopy (the open camera hole cost speed) | - | CFD smooth-wall | Sand to a polish; closed canopy. The CFD `--ks` roughness option quantifies the gain |
| Record day | 4 runs in 1 h, two each direction, independent witnesses, sunset (calm, cold air) | Two Guinness attempts; second on overcharged packs; backup drone ready; witnesses briefed | - | Copy the procedure. Cold calm air is a free few % |
| Failures | ESC fire (TBS Lucid, uncooled); a changed disarm switch caused a crash (muscle memory); a prop came off in flight | Video dropout passing the pilot at speed (lost one Blackbird at 630 km/h); D=0 oscillation; glued frame shifted the resonance | - | Copy the lessons: prop retention test, **don't change switch layouts before a run**, VTX antenna geometry and Doppler |

## 2. What we are running now (generative/optimisation tooling, our equivalents)
| Their tool | Our equivalent | Status |
|---|---|---|
| AirShaper cloud CFD shape optimisation | `cfd/shape_opt.py`: parametric OML, then OpenFOAM RANS (validated pipeline: spheroid within 2.8 %), then a Gaussian-process surrogate with expected improvement | **Running**: 25 evals, coarse mesh for ranking; winner re-run at production mesh |
| Fusion/Onshape hand CAD | Fusion master + CadQuery generator (`cad/src/sq2_v3.py`, 205 interface checks) | Exists; the optimiser winner goes in via `params.json` |
| Generative design for brackets | `sq2/topopt.py` (SIMP topology optimisation) | Exists; apply to the pod node and hub (Bell/Biggs use printed parts, so topology-optimised printed nodes suit us) |
| Strain-gauge thrust rig | Load cell + HX711 + Arduino, current/voltage via ESC telemetry, thermal camera | **To build** (BOM below) |
| Car-window CG test | CFD moment sweep vs CG + a 3D-printed scale model on a stick out of a car window (same as Bell) | Next after the shape optimisation |

## 3. Test-rig BOM to copy (Bell V4 thrust/thermal rig, plus a spinner overspeed test)
- 4 x 10 kg bar load cells (or 1 x 20 kg) + HX711 amplifier + Arduino/ESP32, logging at 80 Hz or more
- ESC telemetry (APD200F3 serial telemetry gives voltage, current, rpm and temperature)
- Thermal camera (any 160x120 or better) aimed at motor and ESC; log alongside
- Rigid rig: 20 mm Al plate on a 4-bar flexure, prop guard, remote arm switch, wired kill
- Spinner overspeed: spin the printed or CNC spinner on a spare motor to 1.5x max rpm (60k), behind polycarbonate

## 4. Honest gaps
- Their exact CFD set-ups (AirShaper mesh, turbulence model, rotating props) are not shown. Our pipeline is RANS
  without props, so relative shape ranking is trustworthy but absolute CdA is not; one validated run so far.
- Biggs's custom sawtooth props: geometry not public. Our BEM cannot model a serrated LE; a spin-rig test is needed.
- Bell's 900 KV step only made sense after his drag reduction. We re-run our KV trade **after** shape optimisation.
